"""Validate and measure one original-size A5 case through actual NPUGraph replay."""
from pathlib import Path
from types import SimpleNamespace
import argparse, csv, hashlib, importlib.util, json, os, re, subprocess, sys, time, traceback
import torch
import torch_npu
import acl

ROOT = Path('/home/s30083169/perf-serial-graph')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resource_snapshot(out, label, expected=None):
    text = subprocess.check_output(['npu-smi', 'info'], text=True)
    (out / ('device-' + label + '.txt')).write_text(text)
    assert re.search(r'^\|\s*7\s*\|\s*Ascend950\S*\s*\|\s*OK\s*\|', text, re.M), 'NPU7 health missing'
    pids = set(re.findall(r'^\|\s*7\s*\|\s*(\d+)\s*\|', text, re.M))
    assert pids or 'No running processes found in NPU 7' in text, 'NPU7 process table absent'
    if expected is not None and pids != expected:
        raise RuntimeError('RESOURCE_GATE_FAILED: NPU7 process ownership changed: ' + str(sorted(pids)))
    return pids


def prepare_c2(index, report):
    base = ROOT / 'src/compressor_c2_a5'
    validation = load(base / 'tests/validate_npu.py', 'c2_validation')
    cases = json.loads((base / 'tests/manifest.json').read_text())['cases']
    case = cases[index]
    c = load(base / 'source/c_packed_opt/binding.py', 'c2_final_c')
    v = load(base / 'source/c_packed/binding.py', 'c2_final_v')
    builder = load(base / 'tests/inputs.py', 'c2_inputs').build_inputs
    oracle = load(base / 'tests/torch_oracle.py', 'c2_oracle')
    report['axes'] = {k: case[k] for k in ('T', 'B', 'P', 'O_valid', 'O_alloc')}
    try:
        report['validation'] = validation.run_case(index, case, SimpleNamespace(device=0, graph_repeats=0), c, v, builder, oracle, torch)
        report['correctness_status'] = 'FULL_ORIGINAL_RULE_PASS'
    except Exception:
        report['validation_error'] = traceback.format_exc()
        report['correctness_status'] = 'FAIL'
    x, wa, wb, initial, bt, cu, su, sp = builder(case, 'npu:0')
    wp = c.pack_weights(wa, wb)
    pair = torch.empty((case['T'], 1024), dtype=torch.float32, device='npu')
    state = initial.clone()
    output = torch.empty((case['O_alloc'], 512), dtype=torch.bfloat16, device='npu')
    blocks = max(32, min(64, (case['O_valid'] + 255) // 256))
    def call():
        c.project(x, wp, pair)
        v.vector(pair, state, bt, cu, su, sp, output, blocks)
        return output
    def reset():
        state.copy_(initial)
    return call, reset, lambda: None, (x, wa, wb, initial, wp, pair, state, output, bt, cu, su, sp)


def prepare_qli(index, report):
    base = ROOT / 'src/qli_a5'
    sys.path.insert(0, str(base))
    from ascendc_quant_lightning_indexer import prepare_quant_lightning_indexer
    inputs = load(base / 'benchmark/inputs.py', 'qli_inputs')
    validation = load(base / 'tests/validate_npu.py', 'qli_validation')
    oracle = load(base / 'benchmark/oracle/qli_cpu_oracle.py', 'qli_oracle')
    case = inputs.load_cases()[index]
    os.environ['QLI_CPU_INPUT_LIMIT_BYTES'] = str(16 << 30)
    cpu = inputs.make_inputs(case['axes'], 'cpu')
    reference = oracle.from_cpu_benchmark(cpu)
    data = {k: (v.npu() if isinstance(v, torch.Tensor) else v) for k, v in cpu.items()}
    prepared = prepare_quant_lightning_indexer(data['q'], data['k'], data['w'], data['q_descale'], data['k_descale'],
        cu_seqlens_q=data['cu_seqlens_q'], seqused_q=data['seqused_q'], seqused_k=data['seqused_k'], block_table=data['block_table'],
        candidate_topk_blocks=data['candidate_topk_blocks'], candidate_block_size=data['candidate_block_size'])
    total = case['axes']['T']
    report['axes'] = dict(case['axes'], candidate=case['candidate_enabled'], seqused_k=case['metadata_assumption']['seqused_k'])
    # Large cases retain their exact T/P and execute every graph chunk. CPU oracle
    # coverage is explicitly sampled, never reported as full-case certification.
    selected = list(range(total)) if total <= 64 else sorted({0, total-1, 1023, 1024, *[i*(total-1)//31 for i in range(32)]})
    report['oracle_row_indices'] = selected
    def audit():
        for row in selected:
            chunk = tuple(t[row:row+1] if t.numel() else t for t in prepared.outputs)
            validation.validate_v_chunk(reference, oracle, chunk, torch, row, 1)
    report['correctness_status'] = 'FULL_OUTPUT_ORACLE_PASS' if total <= 64 else 'SAMPLED_OUTPUT_ORACLE_PASS'
    existing = ROOT / 'outputs/retest-20261026/qli-validation.json'
    if total <= 64 and existing.exists():
        full = next((r for r in json.loads(existing.read_text())['cases'] if r['case_index'] == index), None)
        if full:
            report['component_validation'] = full
            report['correctness_status'] = 'FULL_ORIGINAL_RULE_PASS'
    report['oracle_rows_checked_per_audit'] = len(selected)
    report['total_query_rows'] = total
    return prepared.run, lambda: None, audit, (cpu, data, prepared, reference)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--operator', choices=['compressor_c2_a5', 'qli_a5'], required=True)
    parser.add_argument('--case', type=int, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    assert out.is_relative_to(ROOT / 'outputs/retest-20261026')
    out.mkdir(parents=True, exist_ok=True)
    report = {'operator': args.operator, 'case_id': args.case, 'mode': 'graph', 'physical_device': 7,
              'runner_sha256': digest(Path(__file__)), 'samples': [], 'started_unix': time.time(),
              'protocol': '10 adjacent 256MiB ArgMax/sync/full graph replay/sync; median complete task sums',
              'frequency_gate': 'UNVERIFIED', 'speedup': None, 'resource_gate_passed': False}
    def save():
        (out / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
    active = False
    config = None
    try:
        assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '7'
        resource_snapshot(out, 'initial', set())
        torch.npu.set_device(0)
        torch.set_num_threads(8)
        torch.npu.matmul.allow_hf32 = False
        torch.set_float32_matmul_precision('highest')
        warm = torch.empty((128, 1024, 1024), dtype=torch.float16, device='npu')
        torch.argmax(warm); torch.npu.synchronize()
        own = resource_snapshot(out, 'initialized')
        assert len(own) == 1, 'Expected exactly one task-owned NPU process'
        call, reset, audit, keepalive = (prepare_c2 if args.operator == 'compressor_c2_a5' else prepare_qli)(args.case, report)
        resource_snapshot(out, 'after-prepare', own)
        reset(); call(); torch.npu.synchronize(); audit()
        reset()
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph):
            output = call()
        reset(); graph.replay(); torch.npu.synchronize(); audit()
        report['graph_replay_oracle_passed'] = True
        report['binaries'] = {str(p.relative_to(ROOT)): digest(p) for p in (ROOT / 'src' / args.operator).rglob('*.so')}
        assert acl.prof.init(str(out)) == 0
        active = True
        config = acl.prof.create_config([0], 1, 0, 0x0001 | 0x0002 | 0x0004)
        assert config and acl.prof.start(config) == 0
        try:
            resource_snapshot(out, 'before-profile', own)
            for sample in range(10):
                reset()
                torch.argmax(warm); torch.npu.synchronize()
                begin = time.time_ns()
                graph.replay(); torch.npu.synchronize()
                end = time.time_ns()
                report['samples'].append({'sample': sample + 1, 'start_unix_ns': begin, 'stop_unix_ns': end})
            resource_snapshot(out, 'after', own)
            report['resource_gate_passed'] = True
        finally:
            assert acl.prof.stop(config) == 0
        audit()
        report['post_measurement_oracle_passed'] = True
        acl.prof.destroy_config(config); config = None
        acl.prof.finalize(); active = False
        with (out / 'export.log').open('w') as log:
            report['export_returncode'] = subprocess.run(['msprof', '--export=on', '--output=' + str(out)], stdout=log, stderr=subprocess.STDOUT, timeout=120).returncode
        report['op_summary_files'] = [str(p.relative_to(out)) for p in out.rglob('op_summary*.csv')]
        assert report['export_returncode'] == 0 and len(report['op_summary_files']) == 1
        report['completed'] = True
    except Exception:
        report['error'] = traceback.format_exc()
        report['completed'] = False
    finally:
        if config:
            acl.prof.destroy_config(config)
        if active:
            acl.prof.finalize()
        report['finished_unix'] = time.time()
        save()
    print(json.dumps({k: v for k, v in report.items() if k not in ('validation', 'component_validation', 'binaries')}, indent=2), flush=True)
    return 0 if report.get('completed') else 2


if __name__ == '__main__':
    raise SystemExit(main())
