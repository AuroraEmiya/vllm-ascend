"""Adapt working-copy build paths/line endings to the installed SDK only."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import tarfile

root = Path('/home/s30083169/perf-serial-graph')
sdk = Path(os.environ['ASCEND_HOME_PATH'])
common = sdk / 'opp/built-in/op_impl/ai_core/tbe/impl/ops_transformer/ascendc/common'
assert (common / 'blaze/gemm/policy/dispatch_policy.h').is_file()
changes = []
patches = []
pristine = root / 'inputs/pristine'
if pristine.is_dir():
    originals = {p.relative_to(pristine).as_posix(): p.read_bytes()
                 for p in pristine.rglob('*') if p.is_file()}
else:
    # Compatibility with the first board run; new manual bundles need no tar.
    with tarfile.open(root / 'a5-inputs-20261026.tar.gz') as package:
        originals = {m.name: package.extractfile(m).read() for m in package.getmembers() if m.isfile()}
for op in ('compressor_c2_a5', 'qli_a5'):
    for path in (root / 'src' / op).rglob('*'):
        if not path.is_file() or 'build' in path.parts:
            continue
        if path.suffix != '.sh' and path.name != 'CMakeLists.txt':
            continue
        rel = path.relative_to(root).as_posix()
        before = originals[rel]
        after = before.replace(b'\r\n', b'\n')
        if op == 'compressor_c2_a5' and path.name == 'CMakeLists.txt':
            old = b'${ASCEND_CANN_PACKAGE_PATH}/opp/vendors/custom_transformer/op_impl/ai_core/tbe/custom_transformer_impl/ascendc/common'
            after = after.replace(old, str(common).encode())
            lines = after.splitlines()
            lines = [line[:-1] + b' ${ASCEND_CANN_PACKAGE_PATH}/aarch64-linux/include)' if line.startswith(b'ascendc_include_directories(') else line for line in lines]
            after = b'\n'.join(lines) + b'\n'
        if after == before:
            continue
        path.write_bytes(after)
        changes.append({'path': rel, 'before_sha256': hashlib.sha256(before).hexdigest(),
                        'after_sha256': hashlib.sha256(after).hexdigest(),
                        'reason': 'Build-only SDK include path and/or CRLF normalization'})
        patches.extend(difflib.unified_diff(before.decode().splitlines(True),
                       after.decode().splitlines(True), fromfile='original/' + rel,
                       tofile='adapted/' + rel))
out = root / 'outputs/retest-20261026'
(out / 'build-adaptations.json').write_text(json.dumps(changes, indent=2) + '\n')
(out / 'build-adaptations.patch').write_text(''.join(patches))
print('BUILD_ADAPTED', len(changes), 'KERNEL_SOURCES_UNCHANGED')
