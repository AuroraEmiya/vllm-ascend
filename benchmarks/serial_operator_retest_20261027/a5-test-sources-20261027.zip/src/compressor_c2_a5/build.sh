#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
: "${ASCEND_HOME_PATH:?source the compatible CANN 9.3 environment first}"
for component in c_packed c_packed_opt; do
  cmake -S "source/$component" -B "source/$component/build" \
    -DCMAKE_BUILD_TYPE=Release -DASCEND_CANN_PACKAGE_PATH="$ASCEND_HOME_PATH" \
    -DSOC_VERSION="${SOC_VERSION:-ascend950dt_9582}"
  cmake --build "source/$component/build" --parallel "${BUILD_JOBS:-4}"
done
