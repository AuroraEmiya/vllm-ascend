"""Untimed, CPU-friendly mathematical oracle for native R=2 packed V."""
import torch


def run(kv, scores, state_cache, state_block_table, cu_seqlens, seqused,
        start_pos, cmp_ratio, max_query_len=None):
    if cmp_ratio != 2 or kv.shape[1] != 512:
        raise ValueError("This contract requires R=2 and D=512")
    total, width = kv.shape
    output = torch.empty((min(total, total // 2 + seqused.numel()), width),
                         dtype=torch.bfloat16, device=kv.device)
    offset = 0
    for request in range(seqused.numel()):
        used, start = int(seqused[request]), int(start_pos[request])
        if used == 0:
            continue
        begin, page = int(cu_seqlens[request]), int(state_block_table[request])
        values, logits = kv[begin:begin + used], scores[begin:begin + used]
        if start % 2:
            historical = state_cache[page, (start - 1) % 32]
            values = torch.cat((historical[:width].unsqueeze(0), values), dim=0)
            logits = torch.cat((historical[width:].unsqueeze(0), logits), dim=0)
        count = values.shape[0] // 2
        if count:
            pairs = values[:2 * count].reshape(count, 2, width)
            weights = torch.softmax(logits[:2 * count].reshape(count, 2, width), dim=1)
            output[offset:offset + count] = (pairs * weights).sum(dim=1).to(torch.bfloat16)
            offset += count
        if (start + used) % 2:
            row = (start + used - 1) % 32
            state_cache[page, row, :width] = kv[begin + used - 1]
            state_cache[page, row, width:] = scores[begin + used - 1]
    return output
