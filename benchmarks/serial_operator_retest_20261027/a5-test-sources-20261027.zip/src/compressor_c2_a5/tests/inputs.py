"""Historical input builder, extracted unchanged from cv_bench.py."""
import torch

def build_inputs(case: dict, dev, hid: int = 5120):
    g = torch.Generator(device="cpu")
    g.manual_seed(int(case["seed"]))
    T, D, P = case["T"], case["D"], case["P"]
    x = torch.randn((T, hid), generator=g).bfloat16()
    # native requires x/wkv/wgate all-BF16 (or all-FP16); the same values are
    # promoted to FP32 for the split route (Triton FP32 weight contract)
    wkv = (torch.randn((D, hid), generator=g) / (hid ** 0.5)).bfloat16()
    wgate = (torch.randn((D, hid), generator=g) / (hid ** 0.5)).bfloat16()
    state0 = torch.randn((P, 32, 2 * D), generator=g) * 0.1
    md = case["metadata"]
    bt = torch.tensor(md["state_block_table"], dtype=torch.int32)
    cu = torch.tensor(md["cu_seqlens"], dtype=torch.int32)
    su = torch.tensor(md["seqused"], dtype=torch.int32)
    sp = torch.tensor(md["start_pos"], dtype=torch.int32)
    to = lambda t: t.to(dev)  # noqa: E731
    return (to(x), to(wkv), to(wgate), to(state0),
            to(bt), to(cu), to(su), to(sp))
