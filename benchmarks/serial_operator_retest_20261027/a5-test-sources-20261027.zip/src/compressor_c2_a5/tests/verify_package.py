"""CPU-only integrity and history checks; does not import the Ascend runtime."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
identity = json.loads((root / "evidence/source_identity.json").read_text(encoding="utf-8"))
for rel, expected in identity["source_files"].items():
    assert hashlib.sha256((root / rel).read_bytes()).hexdigest() == expected, rel
manifest = json.loads((root / "tests/manifest.json").read_text(encoding="utf-8"))
assert len(manifest["cases"]) == 60
summary = json.loads((root / "evidence/performance15.json").read_text(encoding="utf-8"))
assert len(summary["rows"]) == 15
for row in summary["rows"]:
    assert row["C_pass"] and row["CV_pass"] and row["task_count"] == 2
    assert row["eager_audits"] == 3 and row["graph_audits"] == 8
    assert all(x == 0 for x in row["approved_output_bad"])
    assert abs(row["C_us"] + row["V_us"] - row["CV_us"]) < 1e-6
    assert manifest["cases"][row["case"]]["T"] == row["T"]
for path in root.rglob("*.py"):
    ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
for path in root.rglob("*"):
    assert path.suffix not in [".so", ".o", ".pyc", ".zip", ".gz"], str(path)
print("PASS: final source identity, 60-case manifest, historical primary15 gates and Python syntax")
