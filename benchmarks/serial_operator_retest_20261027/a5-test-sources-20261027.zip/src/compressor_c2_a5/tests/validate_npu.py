#!/usr/bin/env python3
"""Validate the final packed C + V, with optional stateful NPUGraph timing."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
PRIMARY15 = [0, 1, 2, 5, 10, 15, 16, 17, 25, 28, 35, 43, 51, 53, 55]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def compare(actual, expected, *, atol=1e-4, rtol=1e-4):
    import torch
    actual, expected = actual.detach().cpu().float(), expected.detach().cpu().float()
    if actual.shape != expected.shape:
        raise AssertionError(f"shape mismatch: {actual.shape} != {expected.shape}")
    difference = (actual - expected).abs()
    bad = (~torch.isfinite(actual) | ~torch.isfinite(expected)
           | (difference > atol + rtol * expected.abs()))
    return {"passed": not bool(bad.any()), "bad": int(bad.sum()),
            "numel": actual.numel(),
            "max_abs": float(difference.max()) if actual.numel() else 0.0}


def reference(case, pair, initial, oracle):
    """Compact only the oracle state; full original state is checked separately."""
    import torch
    md = case["metadata"]
    pages = sorted(set(md["state_block_table"]))
    lookup = {page: i for i, page in enumerate(pages)}
    compact = initial[pages].clone()
    bt = torch.tensor([lookup[p] for p in md["state_block_table"]], dtype=torch.int32)
    cu, su, sp = (torch.tensor(md[key], dtype=torch.int32)
                  for key in ["cu_seqlens", "seqused", "start_pos"])
    output = oracle.run(pair[:, :512], pair[:, 512:], compact, bt, cu, su, sp,
                        2, max(md["seqused"]))
    patches = {}
    for page, start, used in zip(md["state_block_table"], md["start_pos"], md["seqused"]):
        if used and (start + used) % 2:
            slot = (start + used - 1) % 32
            patches[(page, slot)] = compact[lookup[page], slot].clone()
    return output, patches


def check_state(state, initial, patches):
    import torch
    written_bad = untouched_bad = 0
    for first in range(0, state.shape[0], 256):
        got = state[first:first + 256].detach().cpu()
        same = got.view(torch.int32) == initial[first:first + 256].view(torch.int32)
        for (page, slot), expected in patches.items():
            if first <= page < first + got.shape[0]:
                written_bad += compare(got[page - first, slot], expected)["bad"]
                same[page - first, slot] = True
        untouched_bad += int((~same).sum())
    return {"passed": written_bad == 0 and untouched_bad == 0,
            "written_bad": written_bad, "untouched_bit_mismatch": untouched_bad}


def run_case(index, case, args, c, v, builder, oracle, torch):
    x, wa, wb, state0, bt, cu, su, sp = builder(case, f"npu:{args.device}")
    initial = state0.cpu()
    total = int(case["T"])
    valid = int(case["O_valid"])
    refpair = torch.empty((total, 1024), dtype=torch.float32)
    for begin in range(0, total, 8192):
        xx = x[begin:begin + 8192].cpu().float()
        refpair[begin:begin + 8192, :512] = xx @ wa.cpu().float().t()
        refpair[begin:begin + 8192, 512:] = xx @ wb.cpu().float().t()
    full_expected, full_patches = reference(case, refpair, initial, oracle)
    wp = c.pack_weights(wa, wb)
    pair = torch.empty((total, 1024), dtype=torch.float32, device=x.device)
    state = state0.clone()
    output = torch.empty((case["O_alloc"], 512), dtype=torch.bfloat16, device=x.device)
    blocks = max(32, min(64, (valid + 255) // 256))

    def body():
        c.project(x, wp, pair)
        v.vector(pair, state, bt, cu, su, sp, output, blocks)

    def audit():
        ck = compare(pair, refpair)
        out = compare(output[:valid], full_expected[:valid], atol=1e-3, rtol=1e-2)
        strict = compare(output[:valid], full_expected[:valid])
        st = check_state(state, initial, full_patches)
        if not all(z["passed"] for z in [ck, out, st]):
            raise AssertionError(json.dumps({"C": ck, "out": out, "state": st}))
        return {"C": ck, "C+V_output": out, "state": st,
                "strict_output_diagnostic": strict}

    # Check the C component first. V uses these checked projections in its own oracle.
    c.project(x, wp, pair)
    torch.npu.synchronize()
    c_check = compare(pair, refpair)
    if not c_check["passed"]:
        raise AssertionError(f"C precision failed: {c_check}")
    v_expected, v_patches = reference(case, pair.cpu(), initial, oracle)
    state.copy_(state0)
    v.vector(pair, state, bt, cu, su, sp, output, blocks)
    torch.npu.synchronize()
    v_check = compare(output[:valid], v_expected[:valid], atol=1e-3, rtol=1e-2)
    v_state = check_state(state, initial, v_patches)
    if not v_check["passed"] or not v_state["passed"]:
        raise AssertionError(f"V precision/state failed: {v_check}, {v_state}")
    state.copy_(state0)
    body()
    torch.npu.synchronize()
    eager = audit()
    # Capture after warming all host tiling caches. State reset remains outside the graph.
    graph = torch.npu.NPUGraph()
    state.copy_(state0)
    with torch.npu.graph(graph):
        body()
    for _ in range(3):
        state.copy_(state0)
        graph.replay()
        torch.npu.synchronize()
        replay = audit()
    timings = []
    for _ in range(args.graph_repeats):
        state.copy_(state0)
        start, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
        start.record()
        graph.replay()
        end.record()
        end.synchronize()
        timings.append(start.elapsed_time(end) * 1000.0)
    if timings:
        replay = audit()
    return {"case": index, "T": total, "B": case["B"], "P": case["P"],
            "O_valid": valid, "passed": True, "C": c_check, "V": v_check,
            "V_state": v_state, "eager": eager, "graph_replay": replay,
            "event_median_us": statistics.median(timings) if timings else None,
            "event_samples_us": timings,
            "timing_scope": "whole serial C+V NPUGraph Event; state reset outside interval"}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--cases", default="0,5,25,28", help="comma list, primary15, or all")
    ap.add_argument("--graph-repeats", type=int, default=0)
    ap.add_argument("--result", type=Path)
    args = ap.parse_args()
    if args.graph_repeats < 0:
        ap.error("--graph-repeats must be nonnegative")
    import torch
    import torch_npu  # noqa: F401
    torch.npu.set_device(args.device)
    torch.set_num_threads(8)
    cases = json.loads((ROOT / "tests/manifest.json").read_text(encoding="utf-8"))["cases"]
    selected = (list(range(len(cases))) if args.cases == "all" else PRIMARY15
                if args.cases == "primary15" else [int(x) for x in args.cases.split(",")])
    if not selected or any(i < 0 or i >= len(cases) for i in selected):
        ap.error("invalid case index")
    c = load(ROOT / "source/c_packed_opt/binding.py", "final_c")
    v = load(ROOT / "source/c_packed/binding.py", "final_v")
    builder = load(ROOT / "tests/inputs.py", "historical_inputs").build_inputs
    oracle = load(ROOT / "tests/torch_oracle.py", "independent_oracle")
    report = {"completed": False, "version": "c_packed_opt + c_packed V", "rows": []}
    for index in selected:
        row = run_case(index, cases[index], args, c, v, builder, oracle, torch)
        report["rows"].append(row)
        print(f"case={index} C=PASS V=PASS C+V=PASS graph_replay=PASS", flush=True)
        if args.result:
            args.result.parent.mkdir(parents=True, exist_ok=True)
            args.result.write_text(json.dumps(report, indent=2), encoding="utf-8")
    report["completed"] = True
    if args.result:
        args.result.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"passed": len(report["rows"]), "selected": len(selected)}))


if __name__ == "__main__":
    main()
