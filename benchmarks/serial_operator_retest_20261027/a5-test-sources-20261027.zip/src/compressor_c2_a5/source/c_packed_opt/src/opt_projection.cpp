
#include "kernel_operator.h"
using AscendC::Coord;
using AscendC::SetMMLayoutTransform;
using AscendC::Shape;
#include "blaze/gemm/policy/dispatch_policy.h"
#include "blaze/gemm/block/block_mmad.h"
#include "blaze/gemm/block/block_mmad_matmul_basic.h"
#include "blaze/gemm/block/block_scheduler_matmul_basic.h"
#include "blaze/gemm/kernel/kernel_universal.h"
#include "blaze/gemm/kernel/kernel_matmul_basic.h"
#include "blaze/epilogue/block/block_epilogue_empty.h"
#include "blaze_matmul_tiling_data.h"

extern "C" __global__ __aicore__ void opt_projection(
    GM_ADDR x, GM_ADDR w, GM_ADDR out, uint32_t m, uint32_t n, uint32_t k, uint32_t mL1, uint32_t nL1, uint32_t kL1, uint32_t baseM, uint32_t baseN, uint32_t baseK, uint32_t mTailCnt, uint32_t nTailCnt, uint32_t mBaseTailSplitCnt, uint32_t nBaseTailSplitCnt, uint32_t mTailMain, uint32_t nTailMain, uint32_t usedCoreNum, uint32_t l1BufferNum, uint32_t l0cDB) {
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIC_ONLY);
    MatmulTilingData t{};
    t.m=m;
    t.n=n;
    t.k=k;
    t.mL1=mL1;
    t.nL1=nL1;
    t.kL1=kL1;
    t.baseM=baseM;
    t.baseN=baseN;
    t.baseK=baseK;
    t.mTailCnt=mTailCnt;
    t.nTailCnt=nTailCnt;
    t.mBaseTailSplitCnt=mBaseTailSplitCnt;
    t.nBaseTailSplitCnt=nBaseTailSplitCnt;
    t.mTailMain=mTailMain;
    t.nTailMain=nTailMain;
    t.usedCoreNum=usedCoreNum;
    t.l1BufferNum=l1BufferNum;
    t.l0cDB=l0cDB;
    using PS = AscendC::Te::Shape<int64_t,int64_t,int64_t,int64_t>;
    using ND = AscendC::Te::NDExtLayoutPtn;
    using DN = AscendC::Te::DNExtLayoutPtn;
    using Policy = Blaze::Gemm::MatmulMultiBlockBasic<0,0>;
    using MM = Blaze::Gemm::Block::BlockMmad<Policy,bfloat16_t,ND,bfloat16_t,DN,float,ND,float,ND>;
    using Sch = Blaze::Gemm::Block::BlockSchedulerMatmulBasic<PS,0,false,true>;
    using Ep = Blaze::Gemm::Block::BlockEpilogueEmpty;
    using Kernel = Blaze::Gemm::Kernel::GemmUniversal<PS,MM,Ep,Sch>;
    typename Kernel::Params p{};
    p.problemShape = PS{(int64_t)t.m,(int64_t)t.n,(int64_t)t.k,1L};
    auto &mm=p.mmadParams;
    mm.aGmAddr=x; mm.bGmAddr=w; mm.cGmAddr=out;
    mm.mL1=t.mL1; mm.nL1=t.nL1; mm.kL1=t.kL1;
    mm.mL0=t.baseM; mm.nL0=t.baseN; mm.kL0=t.baseK;
    mm.l1Stages=t.l1BufferNum; mm.l0cStages=t.l0cDB;
    auto &sc=p.schParams;
    sc.mL1=t.mL1; sc.nL1=t.nL1; sc.kL1=t.kL1;
    sc.baseM=t.baseM; sc.baseN=t.baseN; sc.baseK=t.baseK;
    sc.mTailCnt=t.mTailCnt; sc.nTailCnt=t.nTailCnt;
    sc.mBaseTailSplitCnt=t.mBaseTailSplitCnt; sc.nBaseTailSplitCnt=t.nBaseTailSplitCnt;
    sc.mTailMain=t.mTailMain; sc.nTailMain=t.nTailMain;
    Kernel kernel; kernel(p);
}
