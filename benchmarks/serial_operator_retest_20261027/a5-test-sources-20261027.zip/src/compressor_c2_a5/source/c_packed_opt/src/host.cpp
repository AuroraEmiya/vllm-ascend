#include <cstdio>

#include <cstdint>
#include <map>
#include "blaze_matmul_tiling.h"
#include "aclrtlaunch_opt_projection.h"
extern "C" int opt_c_forward(void *stream, void *x, void *weight, void *y, uint32_t m) {
    if (!m) return -1;
    try {
    static std::map<uint32_t,MatmulTilingData> cache;
    if (!cache.count(m)) {
        MatmulTilingData t{}; MatmulTilingSwat swat;
        swat.GetTilingData(m,1024,5120,2,t,false,true,false,false,false);
        // Exact-shape tuning only; retain installed SWAT for every other M.
        if (m == 96 || m == 128) {
            t.mL1=t.baseM=(m==96?48:64);
            t.nL1=t.baseN=64;
            t.kL1=1024; t.baseK=256;
            t.usedCoreNum=32; t.l1BufferNum=2; t.l0cDB=2;
            t.mTailCnt=t.nTailCnt=t.mBaseTailSplitCnt=t.nBaseTailSplitCnt=1;
            t.mTailMain=t.nTailMain=0;
        }
        fprintf(stderr,"OPT_ACTUAL M=%u N=%u K=%u mL1=%u nL1=%u kL1=%u baseM=%u baseN=%u baseK=%u cores=%u l1=%u l0c=%u\n",
          t.m,t.n,t.k,t.mL1,t.nL1,t.kL1,t.baseM,t.baseN,t.baseK,t.usedCoreNum,t.l1BufferNum,t.l0cDB);
        cache[m]=t;
    }
    const auto t=cache.at(m);
    return aclrtlaunch_opt_projection(t.usedCoreNum,stream,x,weight,y,t.m,t.n,t.k,t.mL1,t.nL1,t.kL1,t.baseM,t.baseN,t.baseK,t.mTailCnt,t.nTailCnt,t.mBaseTailSplitCnt,t.nBaseTailSplitCnt,t.mTailMain,t.nTailMain,t.usedCoreNum,t.l1BufferNum,t.l0cDB);
    } catch (...) { return -2; }
}

