"""Single-thread fixed-A5 direct-call API. Static BF16 weights are prepacked outside graph."""
import ctypes
from pathlib import Path
import torch
lib=ctypes.CDLL(str(Path(__file__).parent/'build/libopt_host.so'))
lib.opt_c_forward.restype=ctypes.c_int
lib.opt_c_forward.argtypes=[ctypes.c_void_p]*4+[ctypes.c_uint32]
def _device(t):
    if t.device.type!='npu' or t.device.index!=torch.npu.current_device():
        raise ValueError('tensor must be on current NPU')
def pack_weights(wkv,wgate):
    _device(wkv)
    if not (wkv.dtype==wgate.dtype==torch.bfloat16 and wkv.shape==wgate.shape==(512,5120)):
        raise ValueError('weights must be BF16 [512,5120]; arbitrary FP32 unsupported')
    if not all(t.device==wkv.device and t.is_contiguous() for t in (wkv,wgate)):
        raise ValueError('weights must be contiguous on same current NPU')
    return torch.cat((wkv,wgate),dim=0)
def project(x,wpacked,y):
    _device(x)
    if x.ndim!=2 or x.shape[0]<1 or x.shape[1]!=5120 or x.dtype!=torch.bfloat16:
        raise ValueError('x must be nonempty BF16 [T,5120]')
    if wpacked.shape!=(1024,5120) or wpacked.dtype!=torch.bfloat16:
        raise ValueError('packed weights must be BF16 [1024,5120]')
    if y.shape!=(x.shape[0],1024) or y.dtype!=torch.float32:
        raise ValueError('Y must be FP32 [T,1024]')
    if not all(t.device==x.device and t.is_contiguous() for t in (x,wpacked,y)):
        raise ValueError('C tensors must be contiguous on same current NPU')
    rc=lib.opt_c_forward(int(torch.npu.current_stream().npu_stream),x.data_ptr(),wpacked.data_ptr(),y.data_ptr(),x.shape[0])
    if rc:raise RuntimeError('opt_c_forward rc='+str(rc))
    return y
