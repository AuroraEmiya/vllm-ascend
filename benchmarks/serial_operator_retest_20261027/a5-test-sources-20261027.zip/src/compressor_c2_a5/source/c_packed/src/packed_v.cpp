// Independent packed adapter: one fused V consumes two regions of FP32 Y[T,1024].
// Projection row pitch1024; score base offset512. Original V math and synchronization retained.
/**
 * Standalone A5 (ascend950dt_9582 / arch35) Ascend C implementation of the
 * DeepSeekV41CompressorV2 **V-only** logical contract.
 *
 * Scope (frozen by definition.json / README.md):
 *   in : kv[T,512] fp32, scores[T,512] fp32, state[P,32,1024] fp32 (mutated),
 *        state_block_table[B] i32, cu_seqlens[B+1] i32, seqused[B] i32,
 *        start_pos[B] i32, cmp_ratio = 2
 *   out: cmp_kv[O_alloc,512] bf16 packed; only prefix [:O_valid] defined
 *
 * NO Cube projections, NO RMSNorm, NO token-aligned restoration, NO RoPE,
 * NO Indexer, NO KV quantization.
 *
 * Per request b (start = start_pos[b], used = seqused[b], page = block_table[b]):
 *   head  = start & 1                    (odd start -> predecessor row from state)
 *   count = (used + head) / 2            compressed rows produced
 *   virtual row v in [0, used+head):
 *     v == 0 && head -> state[page, (start-1) % 32]   (kv part | score part)
 *     else           -> kv / scores row (cu_seqlens[b] + v - head)
 *   pair p covers virtual rows (2p, 2p+1); per COLUMN d:
 *     w = softmax([s(2p,d), s(2p+1,d)]) ; out = kv(2p,d)*w0 + kv(2p+1,d)*w1
 *   state write, only when (start + used) is odd:
 *     state[page, (start+used-1) % 32] = kv/scores row (cu_seqlens[b] + used - 1)
 *
 * Two kernels, mirroring the frozen baseline's "pool first, state update second"
 * ordering so every historical read completes before any tail write.
 */
#include "kernel_operator.h"

using namespace AscendC;

namespace {
constexpr uint32_t kHeadDim = 512;    // D
constexpr uint32_t kRowWidth = 1024;  // state row = [kv 512 | score 512]
constexpr uint32_t kCacheRows = 32;   // ring rows per page
constexpr uint32_t kMaxBatch = 256;   // host-side guard on B
constexpr uint32_t kMetaElems = 4 * kMaxBatch;      // start|used|page|begin
constexpr uint32_t kCountElems = 2 * kMaxBatch;     // counts | offsets
constexpr uint32_t kMetaBytes = kMetaElems * sizeof(int32_t);
constexpr uint32_t kCountBytes = kCountElems * sizeof(int32_t);
constexpr uint32_t kCalcBytes = 8 * kHeadDim * sizeof(float);
}  // namespace

// ---------------------------------------------------------------------------
// Kernel 1: pooling. Emits compressed rows; reads predecessor state rows.
// ---------------------------------------------------------------------------

static constexpr uint64_t kProjectionStride = 1024;
extern "C" __global__ __aicore__ void packed_v_fused(
    GM_ADDR kvGm, GM_ADDR scoreGm, GM_ADDR stateGm, GM_ADDR blockTableGm,
    GM_ADDR cuSeqLensGm, GM_ADDR seqUsedGm, GM_ADDR startPosGm, GM_ADDR outGm,
    uint32_t batch)
{
    if (batch == 0) {
        return;
    }
    const uint32_t coreIdx = GetBlockIdx();
    const uint32_t coreNum = GetBlockNum();

    GlobalTensor<float> kv, score, state;
    GlobalTensor<int32_t> blockTable, cuSeqLens, seqUsed, startPos;
    GlobalTensor<bfloat16_t> out;
    kv.SetGlobalBuffer((__gm__ float *)kvGm);
    score.SetGlobalBuffer((__gm__ float *)scoreGm);
    state.SetGlobalBuffer((__gm__ float *)stateGm);
    blockTable.SetGlobalBuffer((__gm__ int32_t *)blockTableGm);
    cuSeqLens.SetGlobalBuffer((__gm__ int32_t *)cuSeqLensGm);
    seqUsed.SetGlobalBuffer((__gm__ int32_t *)seqUsedGm);
    startPos.SetGlobalBuffer((__gm__ int32_t *)startPosGm);
    out.SetGlobalBuffer((__gm__ bfloat16_t *)outGm);

    TPipe pipe;
    TQue<QuePosition::VECIN, 1> metaQue;
    TQue<QuePosition::VECIN, 2> dataQue;
    TQue<QuePosition::VECOUT, 2> outQue;
    TQue<QuePosition::VECIN, 1> updQue;    // update phase: terminal token load
    TQue<QuePosition::VECOUT, 1> stateQue; // update phase: GM store staging
    TBuf<TPosition::VECCALC> countBuf;
    TBuf<TPosition::VECCALC> calcBuf;

    pipe.InitBuffer(metaQue, 1, kMetaBytes);
    pipe.InitBuffer(dataQue, 2, 4 * kHeadDim * sizeof(float));
    pipe.InitBuffer(outQue, 2, kHeadDim * sizeof(bfloat16_t));
    pipe.InitBuffer(updQue, 1, 2 * kHeadDim * sizeof(float));
    pipe.InitBuffer(stateQue, 1, 2 * kHeadDim * sizeof(float));
    pipe.InitBuffer(countBuf, kCountBytes);
    pipe.InitBuffer(calcBuf, kCalcBytes);

    // ---- metadata: [startPos | seqUsed | blockTable | cuSeqLens], B each ----
    LocalTensor<int32_t> meta = metaQue.AllocTensor<int32_t>();
    const DataCopyExtParams p1{1, static_cast<uint32_t>(batch * sizeof(int32_t)), 0, 0, 0};
    const DataCopyPadExtParams<int32_t> pad{false, 0, 0, 0};
    DataCopyPad(meta[0], startPos, p1, pad);
    DataCopyPad(meta[kMaxBatch], seqUsed, p1, pad);
    DataCopyPad(meta[2 * kMaxBatch], blockTable, p1, pad);
    DataCopyPad(meta[3 * kMaxBatch], cuSeqLens, p1, pad);
    metaQue.EnQue(meta);
    meta = metaQue.DeQue<int32_t>();

    // ---- per-request compressed-row counts + packed prefix offsets ----
    LocalTensor<int32_t> counts = countBuf.Get<int32_t>();
    int32_t total = 0;
    for (uint32_t b = 0; b < batch; ++b) {
        const int32_t start = meta.GetValue(b);
        const int32_t used = meta.GetValue(kMaxBatch + b);
        const int32_t c = (used + (start & 1)) >> 1;
        counts.SetValue(b, c);
        total += c;
    }

    const uint32_t rowStart = static_cast<uint32_t>((static_cast<uint64_t>(total) * coreIdx) / coreNum);
    const uint32_t rowEnd = static_cast<uint32_t>((static_cast<uint64_t>(total) * (coreIdx + 1)) / coreNum);

    // ================= phase 1: pooling (identical body to v_pool) ==========
    LocalTensor<float> calc = calcBuf.Get<float>();
    LocalTensor<float> tMax = calc[0];
    LocalTensor<float> tA = calc[kHeadDim];
    LocalTensor<float> tB = calc[kHeadDim * 2];
    LocalTensor<float> tSum = calc[kHeadDim * 3];
    LocalTensor<float> acc = calc[kHeadDim * 4];

    uint32_t b = 0;
    int32_t curStart = meta.GetValue(0);
    int32_t curPage = meta.GetValue(2 * kMaxBatch);
    int32_t curBegin = meta.GetValue(3 * kMaxBatch);
    int32_t curOffs = 0;
    int32_t curEnd = counts.GetValue(0);

    for (uint32_t j = rowStart; j < rowEnd; ++j) {
        while (b + 1 < batch && static_cast<int32_t>(j) >= curEnd) {
            ++b;
            curStart = meta.GetValue(b);
            curPage = meta.GetValue(2 * kMaxBatch + b);
            curBegin = meta.GetValue(3 * kMaxBatch + b);
            curOffs = curEnd;
            curEnd = curOffs + counts.GetValue(b);
        }
        const int32_t head = curStart & 1;
        const uint32_t p = j - static_cast<uint32_t>(curOffs);
        const uint32_t vA = 2 * p;
        const uint32_t vB = 2 * p + 1;

        LocalTensor<float> in = dataQue.AllocTensor<float>();
        if (head != 0 && vA == 0) {
            const uint32_t srow = static_cast<uint32_t>((curStart - 1) % kCacheRows);
            const uint64_t base = static_cast<uint64_t>(curPage) * kCacheRows * kRowWidth +
                                  static_cast<uint64_t>(srow) * kRowWidth;
            DataCopy(in[0], state[base], kHeadDim);
            DataCopy(in[kHeadDim * 2], state[base + kHeadDim], kHeadDim);
        } else {
            const uint64_t rowA = static_cast<uint64_t>(curBegin) + (vA - static_cast<uint32_t>(head));
            DataCopy(in[0], kv[rowA * kProjectionStride], kHeadDim);
            DataCopy(in[kHeadDim * 2], score[rowA * kProjectionStride], kHeadDim);
        }
        const uint64_t rowB = static_cast<uint64_t>(curBegin) + (vB - static_cast<uint32_t>(head));
        DataCopy(in[kHeadDim], kv[rowB * kProjectionStride], kHeadDim);
        DataCopy(in[kHeadDim * 3], score[rowB * kProjectionStride], kHeadDim);
        dataQue.EnQue(in);

        LocalTensor<float> r = dataQue.DeQue<float>();
        Max(tMax, r[kHeadDim * 2], r[kHeadDim * 3], kHeadDim);
        Sub(tA, r[kHeadDim * 2], tMax, kHeadDim);
        Sub(tB, r[kHeadDim * 3], tMax, kHeadDim);
        Exp(tA, tA, kHeadDim);
        Exp(tB, tB, kHeadDim);
        Add(tSum, tA, tB, kHeadDim);
        Reciprocal(tSum, tSum, kHeadDim);
        Mul(tA, tA, tSum, kHeadDim);
        Mul(tB, tB, tSum, kHeadDim);
        Mul(tA, r[0], tA, kHeadDim);
        Mul(tB, r[kHeadDim], tB, kHeadDim);
        Add(acc, tA, tB, kHeadDim);
        dataQue.FreeTensor(r);

        LocalTensor<bfloat16_t> o = outQue.AllocTensor<bfloat16_t>();
        Cast(o, acc, RoundMode::CAST_RINT, kHeadDim);
        outQue.EnQue(o);
        LocalTensor<bfloat16_t> oo = outQue.DeQue<bfloat16_t>();
        DataCopy(out[static_cast<uint64_t>(j) * kHeadDim], oo, kHeadDim);
        outQue.FreeTensor(oo);
    }

    // ---- all pool reads of state are done; publish the barrier before any
    // ---- core may write a terminal state row (read-before-write guarantee,
    // ---- same as the two-kernel stream order).
    SyncAll();

    // ============ phase 2: terminal-only state update (as v_state_update) ====
    const uint32_t bStart = static_cast<uint32_t>((static_cast<uint64_t>(batch) * coreIdx) / coreNum);
    const uint32_t bEnd = static_cast<uint32_t>((static_cast<uint64_t>(batch) * (coreIdx + 1)) / coreNum);
    for (uint32_t rb = bStart; rb < bEnd; ++rb) {
        const int32_t start = meta.GetValue(rb);
        const int32_t used = meta.GetValue(kMaxBatch + rb);
        if (used == 0 || ((start + used) & 1) == 0) {
            continue;  // tail is complete -> this call writes no state for rb
        }
        const int32_t page = meta.GetValue(2 * kMaxBatch + rb);
        const int32_t begin = meta.GetValue(3 * kMaxBatch + rb);
        const uint32_t srow = static_cast<uint32_t>((start + used - 1) % kCacheRows);
        const uint64_t srcRow = static_cast<uint64_t>(begin) + static_cast<uint64_t>(used) - 1;
        const uint64_t dstBase = static_cast<uint64_t>(page) * kCacheRows * kRowWidth +
                                 static_cast<uint64_t>(srow) * kRowWidth;

        LocalTensor<float> in = updQue.AllocTensor<float>();
        DataCopy(in[0], kv[srcRow * kProjectionStride], kHeadDim);
        DataCopy(in[kHeadDim], score[srcRow * kProjectionStride], kHeadDim);
        updQue.EnQue(in);
        LocalTensor<float> r = updQue.DeQue<float>();

        LocalTensor<float> ost = stateQue.AllocTensor<float>();
        DataCopy(ost[0], r[0], 2 * kHeadDim);
        updQue.FreeTensor(r);
        stateQue.EnQue(ost);
        LocalTensor<float> o2 = stateQue.DeQue<float>();
        DataCopy(state[dstBase], o2[0], kHeadDim);
        DataCopy(state[dstBase + kHeadDim], o2[kHeadDim], kHeadDim);
        stateQue.FreeTensor(o2);
    }
    metaQue.FreeTensor(meta);
}
