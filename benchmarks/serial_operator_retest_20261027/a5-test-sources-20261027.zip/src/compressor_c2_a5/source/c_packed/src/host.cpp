
#include <cstdint>
#include <map>
#include "blaze_matmul_tiling.h"
#include "aclrtlaunch_packed_projection.h"
extern "C" int packed_c_forward(void *stream, void *x, void *weight, void *y, uint32_t m) {
    if (!m) return -1;
    try {
    static std::map<uint32_t,MatmulTilingData> cache;
    if (!cache.count(m)) {
        MatmulTilingData t{}; MatmulTilingSwat swat;
        swat.GetTilingData(m,1024,5120,2,t,false,true,false,false,false);
        cache[m]=t;
    }
    const auto t=cache.at(m);
    return aclrtlaunch_packed_projection(t.usedCoreNum,stream,x,weight,y,t.m,t.n,t.k,t.mL1,t.nL1,t.kL1,t.baseM,t.baseN,t.baseK,t.mTailCnt,t.nTailCnt,t.mBaseTailSplitCnt,t.nBaseTailSplitCnt,t.mTailMain,t.nTailMain,t.usedCoreNum,t.l1BufferNum,t.l0cDB);
    } catch (...) { return -2; }
}

#include "aclrtlaunch_packed_v_fused.h"
extern "C" int packed_v_forward(uint32_t blocks,void* stream,void* y,void* state,void* bt,void* cu,void* su,void* sp,void* out,uint32_t b) {
 auto score=static_cast<void*>(static_cast<char*>(y)+512*sizeof(float));
 return aclrtlaunch_packed_v_fused(blocks,stream,y,score,state,bt,cu,su,sp,out,b);
}
