"""Single-thread fixed-A5 direct-call API. Static BF16 weights are prepacked outside graph."""
import ctypes
from pathlib import Path
import torch
lib=ctypes.CDLL(str(Path(__file__).parent/'build/libpacked_host.so'))
lib.packed_c_forward.restype=ctypes.c_int
lib.packed_c_forward.argtypes=[ctypes.c_void_p]*4+[ctypes.c_uint32]
lib.packed_v_forward.restype=ctypes.c_int
lib.packed_v_forward.argtypes=[ctypes.c_uint32]+[ctypes.c_void_p]*8+[ctypes.c_uint32]
def _device(t):
    if t.device.type!='npu' or t.device.index!=torch.npu.current_device():
        raise ValueError('tensor must be on current NPU')
def pack_weights(wkv,wgate):
    _device(wkv)
    if not (wkv.dtype==wgate.dtype==torch.bfloat16 and wkv.shape==wgate.shape==(512,5120)):
        raise ValueError('weights must be BF16 [512,5120]; arbitrary FP32 unsupported')
    if not all(t.device==wkv.device and t.is_contiguous() for t in (wkv,wgate)):
        raise ValueError('weights must be contiguous on same current NPU')
    return torch.cat((wkv,wgate),dim=0)
def project(x,wpacked,y):
    _device(x)
    if x.ndim!=2 or x.shape[0]<1 or x.shape[1]!=5120 or x.dtype!=torch.bfloat16:
        raise ValueError('x must be nonempty BF16 [T,5120]')
    if wpacked.shape!=(1024,5120) or wpacked.dtype!=torch.bfloat16:
        raise ValueError('packed weights must be BF16 [1024,5120]')
    if y.shape!=(x.shape[0],1024) or y.dtype!=torch.float32:
        raise ValueError('Y must be FP32 [T,1024]')
    if not all(t.device==x.device and t.is_contiguous() for t in (x,wpacked,y)):
        raise ValueError('C tensors must be contiguous on same current NPU')
    rc=lib.packed_c_forward(int(torch.npu.current_stream().npu_stream),x.data_ptr(),wpacked.data_ptr(),y.data_ptr(),x.shape[0])
    if rc:raise RuntimeError('packed_c_forward rc='+str(rc))
    return y
def vector(y,state,bt,cu,su,sp,out,blocks):
    _device(y)
    if y.ndim!=2 or y.shape[1]!=1024 or y.dtype!=torch.float32 or not y.is_contiguous():
        raise ValueError('V input must be contiguous FP32 Y[T,1024]')
    b=bt.numel()
    if not 1<=b<=256:raise ValueError("B must be 1..256 (fixed metadata UB capacity)")
    if not (state.ndim==3 and state.shape[1:]==(32,1024) and state.dtype==torch.float32):
        raise ValueError('state must be FP32 [P,32,1024]')
    if not (bt.shape==su.shape==sp.shape==(b,) and cu.shape==(b+1,)):
        raise ValueError('metadata shape mismatch')
    if not all(t.dtype==torch.int32 for t in (bt,cu,su,sp)):
        raise ValueError('metadata must be int32')
    if out.ndim!=2 or out.shape[1]!=512 or out.dtype!=torch.bfloat16:
        raise ValueError('output must be BF16 [O_alloc,512]')
    if not all(t.device==y.device and t.is_contiguous() for t in (state,bt,cu,su,sp,out)):
        raise ValueError('V tensors must be contiguous on current NPU')
    if not 1<=blocks<=64:raise ValueError('blocks must be 1..64')
    rc=lib.packed_v_forward(blocks,int(torch.npu.current_stream().npu_stream),y.data_ptr(),state.data_ptr(),bt.data_ptr(),cu.data_ptr(),su.data_ptr(),sp.data_ptr(),out.data_ptr(),b)
    if rc:raise RuntimeError('packed_v_forward rc='+str(rc))
    return out
