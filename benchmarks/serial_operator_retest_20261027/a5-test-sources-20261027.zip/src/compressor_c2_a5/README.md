# DeepSeek V4.1 C2 A5 最终源码包

最终默认：`c_packed_opt` 的 packed Blaze C + `c_packed` 的 stride-aware V。
后来的通用 tiling 候选在固定15例上与该版持平，历史报告要求保留本版默认。

接口：BF16 X[T,5120]、BF16 Wkv/Wgate[512,5120] → FP32 Y[T,1024]
→ ratio-2 压缩与 FP32 Ring[P,32,1024]更新 → BF16 packed output[O_alloc,512]。
只定义前 O_valid 行。权重拼接在图外完成，真实投影与V在同一stream依次执行。
此接口不包含 RMSNorm、token恢复和RoPE。绑定要求当前设备、连续张量和单线程host cache。

## 文件

- `source/c_packed_opt/`：最终C。T=96/128使用历史已选tiling，其余SWAT。
- `source/c_packed/`：最终V及原始配套构建工程。其C入口作为同库必要构建组件保留；测试只使用opt C。
- `source/tiling/`：构建所需的三份确切host tiling头文件。
- `tests/`：历史60-case manifest、原输入构造、CPU数学oracle、实际NPU验收/图计时脚本。
- `PERFORMANCE.md`、`evidence/`：最终默认版的15-case设备时延及源码身份。

## 构建和验证

已验证历史平台 A5 Ascend950DT，CANN9.3，编译SoC `ascend950dt_9582`，Python3.11.10及对应torch/torch_npu。
需要SDK自带custom_transformer的Blaze/tensor_api头文件；从兼容CANN环境执行：

```bash
bash build.sh
python -B tests/validate_npu.py --device 0 --cases 0,5,25,28
python -B tests/validate_npu.py --device 0 --cases primary15 --graph-repeats 20 --result results/primary15.json
```

测试逐元素检查独立CPU FP32投影、有效BF16输出、完整Ring及未写状态；复位在图计时外。
默认输出标准atol=1e-3/rtol=1e-2，投影/写入state为1e-4，untouched位级不变。
较早BF16 1e-4标准仅作诊断并保留超限计数。输出零有效行也检查state。
测试采用相同历史输入构造。`all`为60条manifest，但最终C+V历史认证只覆盖primary15。
新脚本的可选Event时间包含图replay运行时影响，不能直接替换历史msprof设备计算时间。

CPU离线包核验：`python -B tests/verify_package.py`。
本次只取回/整理、核对源码hash和语法，未重新构建或上板。
