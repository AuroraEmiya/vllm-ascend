# QLI A5 source package

This folder contains the public Python API package and its required Ascend C sources for the DeepSeek V4.1 Flash A5 QLI B path. The API is `ascendc_quant_lightning_indexer.quant_lightning_indexer`; split C/V internals remain implementation details.

## Contents

- `ascendc_quant_lightning_indexer/`: public package, C kernels, Python dispatch, host bindings, and build files. No shared libraries or Python bytecode are included.
- `benchmark/`: 12-case manifest/workload, synthetic input constructor, independent NumPy CPU oracle, and offline package/manifest validator.
- `evidence/`: compact JSON performance summaries and source manifest.
- `DESIGN.md`, `INTEGRATION.md`: design and build/integration details.
- `PERFORMANCE.md`: measured results, workload assumptions, and evidence limits.
- `PROVENANCE.md`: exact source paths for code, evidence, inputs, and oracle.
- `tests/test_package_static.py`, `tests/test_raw_layout.py`: stdlib syntax, manifest, API export, and raw-layout address checks.
- `tests/validate_npu.py`: NPU C/V/combined correctness runner, with optional graph replay timing.

## Local checks

From this directory, run:

```powershell
python tests/test_package_static.py
python tests/test_raw_layout.py
python benchmark/validate_package.py
python tests/validate_npu.py --help
```

The AST check includes all package, benchmark, oracle, and test Python files. The package validator checks frozen case and input metadata. The address simulation verifies the QGROUP8_N128 to ND permutation without importing NumPy or requiring an NPU. `--help` is CPU-only. Running the independent oracle requires NumPy; input construction also needs PyTorch CPU.

## NPU validation and timing

On the supported A5 environment, build the package as described in `ascendc_quant_lightning_indexer/README.md`, then run `python tests/validate_npu.py --device 0`. By default it exercises cases 0 and 1 (candidate off/on): every 1024-row chunk is checked separately through C and V, then the complete public C+V output is checked against the oracle. C's packed `QGROUP8_N128` raw storage is converted to logical ND before comparison. Add `--graph-timing-iterations N` to time public-wrapper graph replay; `--baseline-b-us X` adds a ratio only when X is a matched B result. Cases with T>64 and long keys require explicit opt-in flags.

The inputs use synthetic metadata assumptions and do not establish whole-model or production-frequency validation. The public API was not rebuilt or run on NPU during this packaging pass. Historical kernel correctness and performance apply to the measured C/V implementation in `PERFORMANCE.md`, not as NPU validation of the new Python adapter.
