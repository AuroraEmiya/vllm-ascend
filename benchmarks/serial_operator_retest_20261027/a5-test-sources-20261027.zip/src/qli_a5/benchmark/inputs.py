"""Synthetic QLI B inputs for the A5-observed T/P geometry.

The CSVs contain no sequence metadata or direct QLI invocation. Batch
segmentation, S2 and shared physical pages are explicit test assumptions.
This module imports torch only when tensors are materialized; it never imports
torch_npu. Large cases must be provisioned with their original dimensions.
"""

from __future__ import annotations

import json
import os
from pathlib import Path


HERE = Path(__file__).resolve().parent
INPUT_NAMES = (
    "q", "k", "w", "q_descale", "k_descale", "cu_seqlens_q",
    "seqused_q", "seqused_k", "block_table", "candidate_topk_blocks",
    "candidate_block_size", "max_seqlen_q",
)
_batch = None


def load_cases():
    return json.loads((HERE / "case_manifest.json").read_text(encoding="utf-8"))["cases"]


def case_for_axes(axes):
    case = load_cases()[int(axes["case_index"])]
    if case["axes"] != {key: int(value) for key, value in axes.items()}:
        raise ValueError("workload axes do not match case manifest")
    return case


def tensor_bytes(case):
    t, p = case["axes"]["T"], case["axes"]["P"]
    m = case["metadata_assumption"]
    b, pages = m["B"], m["block_pages"]
    return 2304 * t + 4352 * p + 4 * (b + 1 + b + b + b * pages)


def describe_case(axes):
    case = case_for_axes(axes)
    t, p = case["axes"]["T"], case["axes"]["P"]
    m = case["metadata_assumption"]
    b, pages = m["B"], m["block_pages"]
    return {
        "id": case["id"], "input_bytes_min": tensor_bytes(case),
        "inputs": {
            "q": ([t, 32, 64], "uint8"),
            "k": ([p, 64, 1, 64], "uint8"),
            "w": ([t, 32], "float32"),
            "q_descale": ([t, 32, 2, 2], "uint8"),
            "k_descale": ([p, 64, 1, 2, 2], "uint8"),
            "cu_seqlens_q": ([b + 1], "int32"),
            "seqused_q": ([b], "int32"),
            "seqused_k": ([b], "int32"),
            "block_table": ([b, pages], "int32"),
        },
        "outputs": {
            "sparse_indices": ([t, 1, 512], "int32"),
            "sparse_values": ([t, 1, 512], "bfloat16"),
            "candidate_indices": ([t, 1, 2048] if case["candidate_enabled"] else [0], "int32"),
            "candidate_length": ([t, 1] if case["candidate_enabled"] else [0], "int32"),
        },
        "metadata_assumption": case["metadata_assumption"],
    }


def make_inputs(axes, device):
    import torch

    case = case_for_axes(axes)
    t, p = case["axes"]["T"], case["axes"]["P"]
    # Prevent accidental many-GB CPU construction in static tests. Set a
    # conscious limit when running a full case; changing it never changes T/P.
    limit = int(os.environ.get("QLI_CPU_INPUT_LIMIT_BYTES", str(1 << 30)))
    if torch.device(device).type == "cpu" and tensor_bytes(case) > limit:
        raise MemoryError(f"{case['id']} needs at least {tensor_bytes(case)} input bytes; raise QLI_CPU_INPUT_LIMIT_BYTES explicitly")
    rng = torch.Generator(device="cpu").manual_seed(case["seed"])
    # All E2M1 nibble codes are finite; both signs exercise ReLU on QK.
    q_lo = torch.randint(0, 16, (t, 32, 64), generator=rng, dtype=torch.uint8)
    q_hi = torch.randint(0, 16, (t, 32, 64), generator=rng, dtype=torch.uint8)
    q = q_lo | (q_hi << 4)
    k_lo = torch.randint(0, 16, (p, 64, 1, 64), generator=rng, dtype=torch.uint8)
    k_hi = torch.randint(0, 16, (p, 64, 1, 64), generator=rng, dtype=torch.uint8)
    k = k_lo | (k_hi << 4)
    w = torch.randint(-8, 9, (t, 32), generator=rng, dtype=torch.int32).to(torch.float32) * 0.125
    q_descale = torch.randint(124, 129, (t, 32, 2, 2), generator=rng, dtype=torch.uint8)
    k_descale = torch.randint(124, 129, (p, 64, 1, 2, 2), generator=rng, dtype=torch.uint8)
    segment = case["metadata_assumption"]["query_segment"]
    b = case["metadata_assumption"]["B"]
    pages = case["metadata_assumption"]["block_pages"]
    s2 = case["metadata_assumption"]["seqused_k"]
    values = {
        "q": q, "k": k, "w": w, "q_descale": q_descale,
        "k_descale": k_descale,
        "cu_seqlens_q": torch.arange(b + 1, dtype=torch.int32) * segment,
        "seqused_q": torch.full((b,), segment, dtype=torch.int32),
        "seqused_k": torch.full((b,), s2, dtype=torch.int32),
        "block_table": torch.arange(pages, dtype=torch.int32).reshape(1, pages).expand(b, pages).contiguous(),
        "candidate_topk_blocks": 2048 if case["candidate_enabled"] else -1,
        "candidate_block_size": 8 if case["candidate_enabled"] else -1,
        "max_seqlen_q": segment,
    }
    return {name: value.to(device) if isinstance(value, torch.Tensor) else value for name, value in values.items()}


def clear_custom_input_batch():
    global _batch
    _batch = None


def make_inputs_for_loader(axes, device):
    """One batch across ordered kernelbench callbacks; clear on interruption."""
    global _batch
    key = (tuple(sorted((name, int(value)) for name, value in axes.items())), str(device))
    if _batch is None or _batch[0] != key:
        _batch = [key, make_inputs(axes, device), 0]
    result = _batch[1]
    _batch[2] += 1
    if _batch[2] == len(INPUT_NAMES):
        _batch = None
    return result
