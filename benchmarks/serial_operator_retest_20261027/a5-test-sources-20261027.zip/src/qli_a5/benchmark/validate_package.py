"""Validate QLI B draft package without NPU. Add --cpu-small for tensors."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import inputs


HERE = Path(__file__).resolve().parent


def main(cpu_small: bool, loader: bool) -> None:
    manifest = json.loads((HERE / "case_manifest.json").read_text(encoding="utf-8"))
    definition = json.loads((HERE / "definition.json").read_text(encoding="utf-8"))
    workloads = [json.loads(line) for line in (HERE / "workload.jsonl").read_text(encoding="utf-8").splitlines()]
    cases = manifest["cases"]
    assert len(cases) == len(workloads) == 12
    assert len({case["id"] for case in cases}) == 12
    assert definition["custom_inputs_entrypoint"] == "make_inputs_for_loader"
    assert list(definition["inputs"]) == list(inputs.INPUT_NAMES)
    for case, workload in zip(cases, workloads):
        axes = case["axes"]
        desc = inputs.describe_case(axes)
        m = case["metadata_assumption"]
        assert workload["uuid"] == case["id"]
        assert workload["axes"] == axes
        assert set(workload["inputs"]) == set(inputs.INPUT_NAMES)
        assert axes["P"] == 62884
        assert m["B"] * m["query_segment"] == axes["T"]
        assert m["query_segment"] <= 1021
        assert desc["inputs"]["block_table"][0] == [m["B"], m["block_pages"]]
        assert {name: {"shape": shape, "dtype": dtype} for name, (shape, dtype) in desc["outputs"].items()} == case["expected_outputs"]
        assert desc["input_bytes_min"] > 0
        assert m["mask_mode"] == 3 and m["cmp_ratio"] == 1
        assert 512 < m["seqused_k"] <= m["block_pages"] * 64
        assert m["block_pages"] <= axes["P"]
        assert case["source_status"].startswith("T/P from adjacent")
    assert {case["axes"]["T"] for case in cases} == {16, 64, 131072, 524288, 2097152}
    assert {case["candidate_enabled"] for case in cases} == {False, True}
    assert sum(case["metadata_assumption"]["seqused_k"] == 32773 for case in cases) == 2
    if loader:
        from npu_kernelbench.data.definition import Definition
        from npu_kernelbench.data.workload import Workload

        Definition.model_validate(definition)
        for workload in workloads:
            Workload.model_validate(workload)
        print("kernelbench Pydantic schema: PASS")
    if cpu_small:
        import torch

        case = cases[0]
        data = inputs.make_inputs(case["axes"], torch.device("cpu"))
        assert list(data) == list(inputs.INPUT_NAMES)
        assert tuple(data["q"].shape) == (16, 32, 64) and data["q"].dtype == torch.uint8
        assert tuple(data["k"].shape) == (62884, 64, 1, 64) and data["k"].dtype == torch.uint8
        assert tuple(data["q_descale"].shape) == (16, 32, 2, 2)
        assert tuple(data["k_descale"].shape) == (62884, 64, 1, 2, 2)
        assert tuple(data["w"].shape) == (16, 32) and data["w"].dtype == torch.float32
        assert data["q"].is_contiguous() and data["k"].is_contiguous()
        assert data["q_descale"].is_contiguous() and data["k_descale"].is_contiguous()
        assert data["w"].is_contiguous()
        assert data["cu_seqlens_q"].tolist() == list(range(17))
        assert data["seqused_q"].tolist() == [1] * 16
        assert data["seqused_k"].tolist() == [1021] * 16
        assert data["block_table"].shape == (16, 16)
        assert data["block_table"].min().item() == 0
        assert data["block_table"].max().item() == 15
        assert data["candidate_topk_blocks"] == -1
        assert data["candidate_block_size"] == -1
        assert data["max_seqlen_q"] == 1
        assert int(data["q_descale"].min()) >= 124 and int(data["q_descale"].max()) <= 128
        assert int(data["k_descale"].min()) >= 124 and int(data["k_descale"].max()) <= 128
        print("CPU T=16 input shape/dtype/metadata: PASS")
    print("Static 12-case manifest and workload: PASS")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-small", action="store_true")
    parser.add_argument("--loader", action="store_true")
    args = parser.parse_args()
    main(args.cpu_small, args.loader)
