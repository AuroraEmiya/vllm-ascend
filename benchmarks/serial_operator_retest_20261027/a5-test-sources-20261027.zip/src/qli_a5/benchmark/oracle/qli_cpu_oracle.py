"""Independent CPU semantic oracle for B (NumPy only; no device execution).

Source of BF16 single-round FMA algorithm:
code/vllm-ascend/csrc/attention/quant_lightning_indexer_v2/tests/pytest/
quant_lightning_indexer_v2_golden.py:141-168, revision
125924bb2cb5ca3f68368f251c01c705d3a67b10, SHA256
044c1179760711b6ecf444ad531bff3e6de9c546abd99fd3136e6ba4c430bea3.
The algorithm is independently expressed with NumPy. Candidate, masks,
padding, and tie checks follow B source cited in CONTRACT_DESIGN_REVIEW.md.

Values are represented as uint16 BF16 bits. CPU matmul models FP32 QK;
matching native Cube accumulation remains an NPU validation requirement.
"""

from dataclasses import dataclass
import numpy as np


FP4 = np.array([0, .5, 1, 1.5, 2, 3, 4, 6,
                -0., -.5, -1, -1.5, -2, -3, -4, -6], dtype=np.float32)


def bf16_round(value):
    """Direct float64 -> BF16 RNE (no intervening float32 rounding)."""
    value = np.asarray(value, dtype=np.float64)
    mantissa, exponent = np.frexp(value)
    with np.errstate(over="ignore", invalid="ignore"):
        normal = np.ldexp(np.rint(mantissa * 256), exponent - 8)
        subnormal = np.rint(value / (2.0 ** -133)) * (2.0 ** -133)
        rounded = np.where(np.abs(value) < 2.0 ** -126, subnormal, normal)
        rounded = np.where(np.isfinite(value), rounded, value)
        return rounded.astype(np.float32)


def bf16_bits(value):
    return (np.ascontiguousarray(bf16_round(value)).view(np.uint32) >> 16).astype(np.uint16)


def unpack_mxfp4(packed, scale):
    packed, scale = np.asarray(packed), np.asarray(scale)
    if packed.dtype != np.uint8 or scale.dtype != np.uint8:
        raise ValueError("packed data and E8M0 scale must be uint8")
    if packed.shape[-1] != 64 or scale.shape != packed.shape[:-1] + (2, 2):
        raise ValueError("MXFP4 logical D128 requires packed64 and scale[2,2]")
    if np.any(scale == 255):
        raise ValueError("E8M0 NaN code255 is outside this finite-input oracle domain")
    codes = np.stack((packed & 15, packed >> 4), axis=-1).reshape(packed.shape[:-1] + (128,))
    multiplier = np.exp2(scale.reshape(scale.shape[:-2] + (4,)).astype(np.float32) - 127)
    return FP4[codes] * np.repeat(multiplier, 32, axis=-1)


def score_query(q, k, weights):
    """q[32,128], k[S,128], w[32]; finite test domain only."""
    qk = np.maximum(bf16_round(q @ k.T), 0)
    w = bf16_round(weights)
    acc = np.zeros(k.shape[0], dtype=np.float32)
    for h in range(32):
        acc = bf16_round(acc.astype(np.float64) + qk[h].astype(np.float64) * np.float64(w[h]))
    if not np.all(np.isfinite(acc)):
        raise ValueError("score overflow/NaN outside the finite-input oracle domain")
    # B canonicalizes signed zero before encoding its score key.
    return acc + np.float32(0)


def canonical_topk(scores, count):
    """Canonical diagnostic order: score descending, logical index ascending."""
    scores = np.asarray(scores)
    if np.any(np.isnan(scores)):
        raise ValueError("NaN has no frozen ranking policy")
    valid = min(len(scores), count)
    indices = np.full(count, -1, dtype=np.int32)
    values = np.zeros(count, dtype=np.uint16)
    chosen = np.argsort(-scores, kind="stable")[:valid]
    indices[:valid] = chosen
    values[:valid] = bf16_bits(scores[chosen])
    return indices, values


def candidate_scores(scores):
    """Each full block takes max; causal partial last block is mandatory +inf."""
    scores = np.asarray(scores)
    full, tail = divmod(len(scores), 8)
    result = scores[:full * 8].reshape(full, 8).max(axis=1) if full else np.empty(0, np.float32)
    if tail:
        result = np.append(result, np.float32(np.inf))
    return result


@dataclass
class Inputs:
    q: np.ndarray
    k: np.ndarray
    w: np.ndarray
    q_descale: np.ndarray
    k_descale: np.ndarray
    cu_seqlens_q: np.ndarray | None = None
    seqused_q: np.ndarray | None = None
    seqused_k: np.ndarray | None = None
    cmp_residual_k: np.ndarray | None = None
    block_table: np.ndarray | None = None
    mask_mode: int = 3
    cmp_ratio: int = 1
    topk: int = 512
    candidate_topk_blocks: int = -1
    candidate_block_size: int = -1
    return_value: bool = True


def iter_reference_rows(inputs):
    """Yield (query row, sparse scores, block scores); only one QK row resident.

    PA NumPy views retain axis0 padding. Physical pages are gathered per batch;
    full [T,32,S] QK is never materialized. Shapes come from caller's CSV package.
    """
    x = inputs
    if x.q.ndim != 3 or x.q.shape[1:] != (32, 64):
        raise ValueError("q must be [T,32,64]")
    if x.k.ndim != 4 or x.k.shape[2:] != (1, 64):
        raise ValueError("k must be [P,page,1,64]")
    if x.w.dtype != np.float32 or x.w.shape != x.q.shape[:2] or not np.all(np.isfinite(x.w)):
        raise ValueError("weights must be finite FP32[T,32]")
    if x.mask_mode not in (0, 3) or not 1 <= x.cmp_ratio <= 128 or not 1 <= x.topk <= 8192:
        raise ValueError("invalid mask/ratio/topk")
    if (x.candidate_topk_blocks == -1 and x.candidate_block_size != -1) or (
        x.candidate_topk_blocks != -1 and (x.candidate_topk_blocks <= 0 or x.candidate_block_size != 8)
    ):
        raise ValueError("candidate is disabled -1/-1 or enabled C>0/block8")
    residual_needed = x.mask_mode == 3 and x.cmp_ratio != 1
    if residual_needed != (x.cmp_residual_k is not None):
        raise ValueError("cmp_residual_k presence does not match mask/ratio")
    t = len(x.q)
    if t <= 0 or len(x.k) <= 0:
        raise ValueError("B requires nonempty Q and physical K storage")
    prefix = np.asarray([0, t] if x.cu_seqlens_q is None else x.cu_seqlens_q)
    if prefix.ndim != 1 or len(prefix) < 2 or prefix[0] != 0 or prefix[-1] != t or np.any(np.diff(prefix) < 0):
        raise ValueError("invalid cu_seqlens_q prefix")
    page = x.k.shape[1]
    if page <= 0 or page > 1024 or page % 16:
        raise ValueError("invalid PA page size")
    batch = len(prefix) - 1
    for name in ("seqused_q", "seqused_k", "cmp_residual_k"):
        value = getattr(x, name)
        if value is not None and (value.shape != (batch,) or value.dtype != np.int32):
            raise ValueError(f"invalid {name}")
    if x.block_table is not None and (x.block_table.ndim != 2 or x.block_table.shape[0] != batch
                                      or x.block_table.dtype != np.int32):
        raise ValueError("invalid block table")
    capacity = (len(x.k) if x.block_table is None else x.block_table.shape[1]) * page
    for b, (begin, end) in enumerate(zip(prefix[:-1], prefix[1:])):
        used_q = int(end - begin if x.seqused_q is None else x.seqused_q[b])
        sk = int(capacity if x.seqused_k is None else x.seqused_k[b])
        residual = int(0 if not residual_needed else x.cmp_residual_k[b])
        if not 0 <= used_q <= end - begin or not 0 <= sk <= capacity:
            raise ValueError("seqused lengths outside allocated domain")
        if residual_needed and not 0 <= residual < x.cmp_ratio:
            raise ValueError("compression residual outside [0,ratio)")
        ids = np.arange((sk + page - 1) // page) if x.block_table is None else x.block_table[b, :(sk + page - 1) // page]
        if np.any(ids < 0) or np.any(ids >= len(x.k)):
            raise ValueError("physical page out of bounds")
        decoded_k = unpack_mxfp4(x.k[ids], x.k_descale[ids]).reshape(-1, 128)[:sk]
        for row in range(int(begin), int(end)):
            i = row - begin
            length = sk if x.mask_mode == 0 else min(sk, max(0, (sk * x.cmp_ratio + residual - used_q + i + 1) // x.cmp_ratio))
            if i >= used_q:
                length = 0
            q = unpack_mxfp4(x.q[row], x.q_descale[row])
            scores = score_query(q, decoded_k[:length], x.w[row])
            yield row, scores, candidate_scores(scores)


def _guard_cpu_work(inputs, allow_large):
    if len(inputs.q) > 4096 and not allow_large:
        raise ValueError("CPU oracle >4096 query rows requires allow_large=True; plan chunked full verification explicitly")


def from_cpu_benchmark(data):
    """Adapt benchmark.make_inputs(..., 'cpu'); never performs a device transfer.

    max_seqlen_q is launch scheduling, not a numerical oracle input. The
    current package explicitly uses mode3/ratio1/topk512/return_value=True.
    This helper must be revised if those package constants change.
    """
    converted = {}
    for name in ("q", "k", "w", "q_descale", "k_descale", "cu_seqlens_q",
                 "seqused_q", "seqused_k", "block_table"):
        value = data[name]
        if isinstance(value, np.ndarray):
            converted[name] = value
        else:
            if str(value.device) != "cpu":
                raise ValueError("from_cpu_benchmark accepts only existing CPU tensors")
            converted[name] = value.detach().numpy()
    return Inputs(**converted, candidate_topk_blocks=int(data["candidate_topk_blocks"]),
                  candidate_block_size=int(data["candidate_block_size"]))


def reference(inputs, *, allow_large=False):
    """Return indices, values-as-BF16-bits, candidate indices, candidate lengths."""
    _guard_cpu_work(inputs, allow_large)
    t, k, c = len(inputs.q), inputs.topk, inputs.candidate_topk_blocks
    indices = np.full((t, 1, k), -1, np.int32)
    values = np.zeros((t, 1, k), np.uint16)
    candidates = np.full((t, 1, c), -1, np.int32) if c > 0 else np.empty(0, np.int32)
    lengths = np.zeros((t, 1), np.int32) if c > 0 else np.empty(0, np.int32)
    for row, scores, blocks in iter_reference_rows(inputs):
        indices[row, 0], values[row, 0] = canonical_topk(scores, k)
        if c > 0:
            candidates[row, 0], _ = canonical_topk(blocks, c)
            lengths[row, 0] = min(len(blocks), c)
    return indices, values if inputs.return_value else np.empty(0, np.uint16), candidates, lengths


def _check_selection(scores, indices, values=None, strict_ties=False):
    count, valid = len(indices), min(len(scores), len(indices))
    if np.any(indices[valid:] != -1):
        raise AssertionError("invalid index padding")
    picked = indices[:valid]
    if np.any(picked < 0) or np.any(picked >= len(scores)) or len(np.unique(picked)) != valid:
        raise AssertionError("index range/uniqueness/valid count")
    if valid:
        threshold = np.partition(scores, len(scores) - valid)[len(scores) - valid]
        if np.any(scores[picked] < threshold) or not set(np.flatnonzero(scores > threshold)).issubset(set(picked)):
            raise AssertionError("not an exact-score TopK set")
        if strict_ties and set(picked) != set(canonical_topk(scores, count)[0][:valid]):
            raise AssertionError("tie requires lowest logical indices")
    if values is not None:
        if np.any(values[valid:] != 0):
            raise AssertionError("invalid value padding must be +0 BF16")
        if not np.array_equal(values[:valid], bf16_bits(scores[picked])):
            raise AssertionError("value/index pairing or BF16 score mismatch")


def validate(inputs, outputs, *, strict_ties=False, allow_large=False):
    """Strict shape/dtype/mask/value checks; only exact threshold ties interchangeable.

    This policy is a proposal awaiting contract freeze, not an NPU PASS claim.
    For torch outputs use .cpu().numpy(); BF16 values use .view(torch.uint16)
    before .cpu().numpy(). No generic tolerance or recall threshold is applied.
    """
    _guard_cpu_work(inputs, allow_large)
    if len(outputs) != 4:
        raise AssertionError("B requires four outputs")
    idx, val, cand, lens = map(np.asarray, outputs)
    t, k, c = len(inputs.q), inputs.topk, inputs.candidate_topk_blocks
    specs = [(idx, (t, 1, k), np.int32),
             (val, (t, 1, k) if inputs.return_value else (0,), np.uint16),
             (cand, (t, 1, c) if c > 0 else (0,), np.int32),
             (lens, (t, 1) if c > 0 else (0,), np.int32)]
    for value, shape, dtype in specs:
        if value.shape != shape or value.dtype != dtype:
            raise AssertionError(f"output expected {shape}/{dtype}, got {value.shape}/{value.dtype}")
    rows = 0
    for row, scores, blocks in iter_reference_rows(inputs):
        _check_selection(scores, idx[row, 0], val[row, 0] if inputs.return_value else None, strict_ties)
        if c > 0:
            if lens[row, 0] != min(len(blocks), c):
                raise AssertionError("candidate length mismatch")
            _check_selection(blocks, cand[row, 0], strict_ties=strict_ties)
        rows += 1
    return {"status": "CPU_COMPARATOR_PASS", "rows_checked": rows,
            "tie_policy": "lowest_index" if strict_ties else "exact_score_boundary_ties",
            "npu_validated": False}
