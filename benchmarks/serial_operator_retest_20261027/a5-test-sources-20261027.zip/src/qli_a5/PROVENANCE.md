# Provenance

| Included material | Local source |
|---|---|
| Public API, Python dispatch, Ascend C kernel sources, bindings, and build files | `tasks/qli_b_ascendc_20260928/deliverables/ascendc_quant_lightning_indexer/` |
| Design and integration notes; compact profile/result summaries and source manifest | `tasks/qli_b_ascendc_20260928/deliverables/qli_cv_final_20260930/` |
| 12-case workload, manifest, input builder, offline manifest validator | `tasks/qli_b_ascendc_20260928/deliverables/qli_cv_final_20260930/benchmark/` plus `tasks/qli_b_ascendc_20260928/benchmark/validate_package.py` |
| Independent NumPy semantic oracle | `tasks/qli_b_ascendc_20260928/design/qli_cpu_oracle.py` |

The public API package was preferred as requested. Its C/V kernel code is the final implementation family documented by the QLI final package, while the unified Python API is an additional later wrapper. The historical source manifest describes the measured kernel package, not every file in this public API delivery. This packaging operation copied source files without changing them, except for the added outer README, performance report, provenance note, and static validation script.
