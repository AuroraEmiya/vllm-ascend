from __future__ import annotations

import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "ascendc_quant_lightning_indexer"


def main() -> None:
    python_files = sorted(PACKAGE.rglob("*.py")) + sorted((ROOT / "benchmark").rglob("*.py")) + sorted((ROOT / "tests").rglob("*.py"))
    for path in python_files:
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

    init = ast.parse((PACKAGE / "__init__.py").read_text(encoding="utf-8-sig"))
    exports = next(node for node in init.body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__all__" for t in node.targets))
    public_names = set(ast.literal_eval(exports.value))
    assert {"quant_lightning_indexer", "prepare_quant_lightning_indexer", "compute_qk_scores", "select_sparse_indices"} <= public_names

    oracle = ast.parse((ROOT / "benchmark" / "oracle" / "qli_cpu_oracle.py").read_text(encoding="utf-8-sig"))
    oracle_functions = {node.name for node in oracle.body if isinstance(node, ast.FunctionDef)}
    assert {"from_cpu_benchmark", "reference", "validate"} <= oracle_functions

    manifest = json.loads((ROOT / "benchmark" / "case_manifest.json").read_text(encoding="utf-8"))
    workloads = [json.loads(line) for line in (ROOT / "benchmark" / "workload.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(manifest["cases"]) == len(workloads) == 12
    assert len({case["id"] for case in manifest["cases"]}) == 12
    assert all(workload["uuid"] == case["id"] for case, workload in zip(manifest["cases"], workloads))
    print(f"Python AST: PASS ({len(python_files)} files)")
    print("Public API, oracle entry points, and 12-case benchmark manifest: PASS")


if __name__ == "__main__":
    main()

