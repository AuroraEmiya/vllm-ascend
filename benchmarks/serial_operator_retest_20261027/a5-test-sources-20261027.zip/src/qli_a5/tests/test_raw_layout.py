"""Stdlib address simulation of the QGROUP8_N128 to ND permutation."""

def main():
    qcap, heads, s_pad = 16, 32, 256
    storage = []
    for q_group in range(qcap // 8):
        for s_block in range(s_pad // 128):
            for q_lane in range(8):
                for head in range(heads):
                    for s_lane in range(128):
                        q = q_group * 8 + q_lane
                        s = s_block * 128 + s_lane
                        storage.append((q, head, s))

    checked = 0
    for q in range(qcap):
        for head in range(heads):
            for s in range(s_pad):
                q_group, q_lane = divmod(q, 8)
                s_block, s_lane = divmod(s, 128)
                flat = (((q_group * (s_pad // 128) + s_block) * 8 + q_lane) * heads + head) * 128 + s_lane
                assert storage[flat] == (q, head, s)
                checked += 1
    print(f"QGROUP8_N128 address transform: PASS ({checked} logical symbols)")


if __name__ == "__main__":
    main()
