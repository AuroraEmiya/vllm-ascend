"""NPU correctness and optional graph-replay timing for the packaged QLI API.
Defaults validate all C/V chunks and combined outputs for cases 0/1 (candidate off/on).
"""
from __future__ import annotations
import argparse, importlib.util, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT))

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f"cannot load {path}")
    module=importlib.util.module_from_spec(spec); sys.modules[spec.name]=module
    spec.loader.exec_module(module); return module

def raw_reference(data,oracle,start,valid_q,qcap,s_pad):
    import numpy as np
    q,k,qs,ks=(data[n].numpy() for n in ("q","k","q_descale","k_descale"))
    prefix,usedk,table=(data[n].numpy() for n in ("cu_seqlens_q","seqused_k","block_table"))
    expected=np.zeros((qcap,32,s_pad),dtype=np.uint16); decoded={}
    for local,row in enumerate(range(start,start+valid_q)):
        b=int(np.searchsorted(prefix,row,side="right")-1); sk=int(usedk[b])
        if b not in decoded:
            ids=table[b,:(sk+63)//64]
            decoded[b]=oracle.unpack_mxfp4(k[ids],ks[ids]).reshape(-1,128)[:sk]
        expected[local,:,:sk]=oracle.bf16_bits(oracle.unpack_mxfp4(q[row],qs[row]) @ decoded[b].T)
    return expected

def raw_nd_bits(raw,plan,qcap,s_pad):
    import torch
    if raw.dtype!=torch.bfloat16 or tuple(raw.shape)!=(qcap,32,s_pad):
        raise AssertionError("C raw-QK BF16 shape/dtype mismatch")
    bits=raw.view(torch.uint16).detach().cpu().numpy()
    if plan.raw_layout=="ND": return bits
    if plan.raw_layout!="QGROUP8_N128": raise AssertionError(f"unknown raw layout: {plan.raw_layout}")
    return bits.reshape(qcap//8,s_pad//128,8,32,128).transpose(0,2,3,1,4).reshape(qcap,32,s_pad)

def output_arrays(outputs,torch):
    i,v,c,l=outputs
    return i.detach().cpu().numpy(),v.view(torch.uint16).detach().cpu().numpy(),c.detach().cpu().numpy(),l.detach().cpu().numpy()

def validate_v_chunk(x,oracle,outputs,torch,start,n):
    import numpy as np
    idx,val,cand,lens=output_arrays(outputs,torch); c=x.candidate_topk_blocks
    specs=((idx,(n,1,512),np.int32),(val,(n,1,512),np.uint16),
           (cand,(n,1,c) if c>0 else (0,),np.int32),(lens,(n,1) if c>0 else (0,),np.int32))
    for arr,shape,dtype in specs:
        if arr.shape!=shape or arr.dtype!=dtype: raise AssertionError(f"V output expected {shape}/{dtype}; got {arr.shape}/{arr.dtype}")
    decoded={}; prefix=x.cu_seqlens_q
    for local,row in enumerate(range(start,start+n)):
        b=int(np.searchsorted(prefix,row,side="right")-1); i=row-int(prefix[b])
        sk=int(x.seqused_k[b]); uq=int(x.seqused_q[b]); residual=0 if x.cmp_residual_k is None else int(x.cmp_residual_k[b])
        length=sk if x.mask_mode==0 else min(sk,max(0,(sk*x.cmp_ratio+residual-uq+i+1)//x.cmp_ratio))
        if i>=uq: length=0
        if b not in decoded:
            ids=x.block_table[b,:(sk+63)//64]
            decoded[b]=oracle.unpack_mxfp4(x.k[ids],x.k_descale[ids]).reshape(-1,128)[:sk]
        q=oracle.unpack_mxfp4(x.q[row],x.q_descale[row]); scores=oracle.score_query(q,decoded[b][:length],x.w[row])
        oracle._check_selection(scores,idx[local,0],val[local,0])
        if c>0:
            blocks=oracle.candidate_scores(scores)
            if lens[local,0]!=min(len(blocks),c): raise AssertionError("candidate length mismatch")
            oracle._check_selection(blocks,cand[local,0])
    return n

def validate_full_outputs(x,oracle,outputs,torch,chunk_rows=1024):
    total=len(x.q); checked=0
    for start in range(0,total,chunk_rows):
        n=min(chunk_rows,total-start)
        chunk=tuple(t[start:start+n] if t.ndim and t.shape[0]==total else t for t in outputs)
        checked+=validate_v_chunk(x,oracle,chunk,torch,start,n)
    if checked!=total: raise AssertionError(f"oracle covered {checked}/{total} rows")
    return checked

def run_case(case_index,args,torch,input_factory,oracle):
    from ascendc_quant_lightning_indexer import compute_qk_scores,prepare_quant_lightning_indexer,select_sparse_indices
    from ascendc_quant_lightning_indexer.qk_projection.packed import runner as projection
    from ascendc_quant_lightning_indexer.sparse_selection import runner as selection
    case=input_factory.load_cases()[case_index]; axes=case["axes"]; t=int(axes["T"]); p=int(axes["P"])
    meta=case["metadata_assumption"]; s_pad=((int(meta["block_pages"])*64+127)//128)*128
    if t>64 and not args.allow_large: raise ValueError(f"case {case_index} has T={t}; pass --allow-large")
    if s_pad>4096 and not args.allow_long_key: raise ValueError(f"case {case_index} has S_PAD={s_pad}; pass --allow-long-key")
    cpu=input_factory.make_inputs(axes,"cpu"); x=oracle.from_cpu_benchmark(cpu)
    npu=torch.device("npu",args.device); data={k:(v.to(npu) if isinstance(v,torch.Tensor) else v) for k,v in cpu.items()}
    qcap=1024; candidate=int(data["candidate_topk_blocks"]); cblock=int(data["candidate_block_size"])
    selection.load(); c_rows=v_rows=0
    for start in range(0,t,qcap):
        n=min(qcap,t-start); plan=projection.make_plan(qcap,s_pad,n,device=npu)
        raw=projection.allocate_raw(plan,device=npu)
        raw=compute_qk_scores(data["q"][start:start+n],data["k"],data["q_descale"][start:start+n],data["k_descale"],
            data["cu_seqlens_q"],data["seqused_q"],data["seqused_k"],data["block_table"],start,n,qcap,plan=plan,out=raw)
        expected=raw_reference(cpu,oracle,start,n,qcap,s_pad); actual=raw_nd_bits(raw,plan,qcap,s_pad)
        import numpy as np
        if not np.array_equal(actual,expected): raise AssertionError(f"C raw QK mismatch rows [{start},{start+n})")
        c_rows+=n
        vout=selection.allocate_outputs(raw,n,candidate); workspace=selection.allocate_workspace(raw,qcap,candidate)
        vout=select_sparse_indices(raw,data["w"][start:start+n],data["cu_seqlens_q"],data["seqused_q"],data["seqused_k"],data["block_table"],
            start,n,candidate,cblock,plan=plan,out=vout,workspace=workspace)
        v_rows+=validate_v_chunk(x,oracle,vout,torch,start,n)
        print(f"case={case_index} component_chunk=[{start},{start+n}) C=PASS V=PASS")
    if c_rows!=t or v_rows!=t: raise AssertionError(f"component coverage C={c_rows}, V={v_rows}, T={t}")
    prepared=prepare_quant_lightning_indexer(data["q"],data["k"],data["w"],data["q_descale"],data["k_descale"],
        cu_seqlens_q=data["cu_seqlens_q"],seqused_q=data["seqused_q"],seqused_k=data["seqused_k"],block_table=data["block_table"],
        candidate_topk_blocks=candidate,candidate_block_size=cblock)
    combined=prepared.run(); combined_rows=validate_full_outputs(x,oracle,combined,torch)
    print(f"case={case_index} C=PASS rows={c_rows} V=PASS rows={v_rows} C+V=PASS rows={combined_rows}")
    timing=None
    if args.graph_timing_iterations:
        prepared.run(); torch.npu.synchronize(npu); graph=torch.npu.NPUGraph()
        with torch.npu.graph(graph): prepared.run()
        graph.replay(); torch.npu.synchronize(npu)
        begin=torch.npu.Event(enable_timing=True); end=torch.npu.Event(enable_timing=True)
        begin.record()
        for _ in range(args.graph_timing_iterations): graph.replay()
        end.record(); end.synchronize(); us=begin.elapsed_time(end)*1000/args.graph_timing_iterations
        torch.npu.synchronize(npu)
        replay_rows=validate_full_outputs(x,oracle,prepared.outputs,torch)
        if replay_rows!=t: raise AssertionError("post-replay oracle coverage incomplete")
        timing={"scope":"public C+V wrapper graph replay, device events","iterations":args.graph_timing_iterations,
            "microseconds_per_replay":us,"baseline_b_microseconds":args.baseline_b_us,
            "speedup_vs_b":args.baseline_b_us/us if args.baseline_b_us else None,
            "post_replay_oracle":"PASS","post_replay_rows_checked":replay_rows}
        print(f"case={case_index} GRAPH=PASS us_per_replay={us:.3f} oracle_rows={replay_rows}")
    return {"case_index":case_index,"case_id":case["id"],"T":t,"P":p,"S_PAD":s_pad,"candidate_topk_blocks":candidate,
        "component_C":"PASS","component_V":"PASS","public_C+V":"PASS","component_C_rows":c_rows,"component_V_rows":v_rows,
        "combined_rows":combined_rows,"graph_timing":timing}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device",type=int,default=0,help="NPU device index (default: 0)")
    parser.add_argument("--case-index",type=int,action="append",dest="case_indices",help="manifest index (repeatable; default 0 and 1)")
    parser.add_argument("--allow-large",action="store_true",help="allow T>64 cases; can need substantial memory/time")
    parser.add_argument("--allow-long-key",action="store_true",help="allow S_PAD>4096; C intermediate can require GiB")
    parser.add_argument("--graph-timing-iterations",type=int,default=0,help="public wrapper NPU graph replays; 0 disables timing")
    parser.add_argument("--baseline-b-us",type=float,default=None,help="optional matched B graph time in microseconds")
    parser.add_argument("--result-json",type=Path,default=None,help="optional machine-readable report path")
    args=parser.parse_args()
    if args.graph_timing_iterations<0: parser.error("--graph-timing-iterations must be nonnegative")
    if args.baseline_b_us is not None and args.baseline_b_us<=0: parser.error("--baseline-b-us must be positive")
    try:
        import torch
        import torch_npu  # noqa: F401
    except ImportError as exc: raise SystemExit(f"NPU validation requires torch and torch_npu: {exc}") from exc
    input_factory=load_module(ROOT/"benchmark"/"inputs.py","qli_package_inputs")
    oracle=load_module(ROOT/"benchmark"/"oracle"/"qli_cpu_oracle.py","qli_package_cpu_oracle")
    cases=input_factory.load_cases(); indices=args.case_indices if args.case_indices is not None else [0,1]
    if any(i<0 or i>=len(cases) for i in indices): parser.error(f"case indices must be in [0,{len(cases)-1}]")
    torch.npu.set_device(args.device)
    reports=[run_case(i,args,torch,input_factory,oracle) for i in indices]
    report={"status":"PASS","device":args.device,"cases":reports,"scope":"synthetic A5 QLI B inputs; not whole-model validation"}
    if args.result_json:
        args.result_json.parent.mkdir(parents=True,exist_ok=True)
        args.result_json.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))

if __name__=="__main__": main()
