#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for component in qk_projection/packed qk_projection/pair qk_projection/quad qk_projection/dispatch sparse_selection; do
  bash "$component/build.sh"
done
