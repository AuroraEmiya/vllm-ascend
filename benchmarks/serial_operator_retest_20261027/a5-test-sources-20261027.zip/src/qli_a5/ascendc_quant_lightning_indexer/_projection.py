"""Shape-plan dispatch between two frozen C kernels; no fused C/V execution."""
import importlib.util
from pathlib import Path
import torch
import torch_npu

GEN = Path(__file__).resolve().parent


def _load(name):
    spec = importlib.util.spec_from_file_location('hybrid_' + name, GEN / name / 'runner.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


packed = _load('qk_projection/packed')
nd = _load('qk_projection/dispatch')
make_plan = packed.make_plan
allocate_raw = packed.allocate_raw
validate_plan = packed.validate_plan
_loaded = False


def load():
    global _loaded
    if not _loaded:
        packed.load()
        nd.load()
        _loaded = True


def run(q, k, q_descale, k_descale, cu_seqlens_q, seqused_q, seqused_k,
        block_table, row_offset, valid_q, qcap, *, plan, out=None):
    sp = ((block_table.shape[1] * 64 + 127) // 128) * 128
    validate_plan(plan, qcap, sp, valid_q, q.device)
    if torch.npu.is_current_stream_capturing() and (not _loaded or out is None):
        raise RuntimeError('Load all frozen C kernels and allocate raw before capture')
    load()
    args = (q, k, q_descale, k_descale, cu_seqlens_q, seqused_q,
            seqused_k, block_table, row_offset, valid_q, qcap)
    if plan.raw_layout == 'QGROUP8_N128':
        raw = packed.run(*args, plan=plan, out=out)
    else:
        raw = nd.run(*args, out=out)
        raw._qli_qgroup8_plan = plan
    if out is not None and raw is not out:
        raise RuntimeError('Frozen C runner returned a different raw allocation')
    return raw
