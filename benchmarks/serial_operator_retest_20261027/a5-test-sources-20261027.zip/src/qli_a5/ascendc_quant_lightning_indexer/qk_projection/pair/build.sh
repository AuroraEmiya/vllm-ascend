#!/usr/bin/env bash
set -euo pipefail
source /usr/local/Ascend/cann/set_env.sh
cd "$(dirname "$0")"
mkdir -p build/tmp evidence
export TMPDIR="$PWD/build/tmp"
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
cmake -S . -B build -DASC_DIR=/usr/local/Ascend/cann/aarch64-linux/lib64/cmake -DPython3_EXECUTABLE=/usr/local/python3.11.10/bin/python3
cmake --build build --target qli_c_a_alias_pair -j4
sha256sum qli_c.asc qli_c.h torch_binding.cpp build/libqli_c_a_alias_pair.so
