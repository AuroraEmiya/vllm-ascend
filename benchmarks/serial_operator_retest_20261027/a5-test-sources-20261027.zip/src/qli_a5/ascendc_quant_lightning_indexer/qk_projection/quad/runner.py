"""General ND C: pure AIC with complete padding for cap<=64/Sp<=1024, otherwise MIX."""
from pathlib import Path
import torch
import torch_npu
_loaded = False
def load():
    global _loaded
    if not _loaded:
        torch.ops.load_library(str(Path(__file__).parent / "build/libqli_c_a_alias4.so"))
        _loaded = True
def run(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,row_offset,valid_q,qcap,*,out=None):
    load()
    args=(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,row_offset,valid_q,qcap)
    return torch.ops.qli_cv_calias4.c(*args) if out is None else torch.ops.qli_cv_calias4.c_out(*args,out)
