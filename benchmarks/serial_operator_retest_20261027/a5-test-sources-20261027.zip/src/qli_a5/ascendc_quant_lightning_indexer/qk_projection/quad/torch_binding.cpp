#include <ATen/ATen.h>
#include <torch/library.h>
#include <c10/core/DeviceGuard.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "acl/acl.h"
#include "qli_c.h"
extern "C" void qli_c_a_alias4_launch(aclrtStream,void*,void*,void*,void*,void*,void*,void*,void*,QliCTiling);

static void check(const at::Tensor& x, const at::Tensor& q, at::ScalarType dt, const char* name) {
    TORCH_CHECK(x.device()==q.device() && x.scalar_type()==dt, name," device/dtype mismatch");
}
at::Tensor calias4_out(const at::Tensor& q,const at::Tensor& k,const at::Tensor& qs,const at::Tensor& ks,
 const at::Tensor& cu,const at::Tensor& usedq,const at::Tensor& usedk,const at::Tensor& table,
 int64_t offset,int64_t valid,int64_t cap,at::Tensor out) {
    TORCH_CHECK(q.is_privateuseone(), "NPU required");
    c10::DeviceGuard guard(q.device());
    for (auto x : {q,k,qs,ks}) check(x,q,at::kByte,"packed input");
    for (auto x : {cu,usedq,usedk,table}) { check(x,q,at::kInt,"metadata"); TORCH_CHECK(x.is_contiguous(),"contiguous metadata required"); }
    TORCH_CHECK(valid>0 && cap>=valid && offset>=0 && offset<=INT32_MAX && cap<=UINT32_MAX,"invalid row controls");
    TORCH_CHECK(q.dim()==3 && q.size(0)==valid && q.size(1)==32 && q.size(2)==64 && q.is_contiguous(),"q shape/stride");
    TORCH_CHECK(qs.dim()==4 && qs.size(0)==valid && qs.size(1)==32 && qs.size(2)==2 && qs.size(3)==2 && qs.is_contiguous(),"qs shape/stride");
    TORCH_CHECK(k.dim()==4 && k.size(1)==64 && k.size(2)==1 && k.size(3)==64 && k.stride(1)==64 && k.stride(3)==1 && k.stride(0)>=4096,"k shape/stride");
    TORCH_CHECK(ks.dim()==5 && ks.size(0)==k.size(0) && ks.size(1)==64 && ks.size(2)==1 && ks.size(3)==2 && ks.size(4)==2 && ks.stride(1)==4 && ks.stride(3)==2 && ks.stride(4)==1 && ks.stride(0)>=256 && ks.stride(0)%2==0,"ks shape/stride");
    TORCH_CHECK(cu.dim()==1 && usedq.dim()==1 && usedk.dim()==1 && table.dim()==2 && usedq.numel()==usedk.numel() && cu.numel()==usedk.numel()+1 && table.size(0)==usedk.numel() && table.size(1)>0,"metadata shapes");
    int64_t sp=((table.size(1)*64+127)/128)*128;
    TORCH_CHECK(sp<=32896,"unsupported S_pad");
    check(out,q,at::kBFloat16,"raw_qk");
    TORCH_CHECK(out.dim()==3 && out.size(0)==cap && out.size(1)==32 && out.size(2)==sp && out.is_contiguous(),"raw_qk shape/stride");
    // Launcher performs C then exact padding-only clear on the same stream.
    int32_t dev=-1; int64_t cores=0, vectorCores=0;
    TORCH_CHECK(aclrtGetDevice(&dev)==ACL_SUCCESS,"device query");
    TORCH_CHECK(aclrtGetDeviceInfo(dev,ACL_DEV_ATTR_CUBE_CORE_NUM,&cores)==ACL_SUCCESS && cores>0,"Cube count query");
    TORCH_CHECK(aclrtGetDeviceInfo(dev,ACL_DEV_ATTR_VECTOR_CORE_NUM,&vectorCores)==ACL_SUCCESS && vectorCores>0,"Vector count query");
    int64_t groupLimit=std::min<int64_t>(16,std::max<int64_t>(1,valid/cores));
    int64_t groupRows=1;
    while(groupRows*2<=groupLimit) groupRows*=2;
    int64_t nt=(sp+255)/256;
    if(groupRows==1 && valid>=2 && uint64_t((valid+1)/2)*uint64_t(nt)>=uint64_t(cores))groupRows=2;
    if(groupRows<=2 && valid>=4 && uint64_t((valid+3)/4)*uint64_t(nt)>=uint64_t(cores))groupRows=4;
    int64_t groups=(valid+groupRows-1)/groupRows;
    int64_t splits=std::min<int64_t>(nt,std::max<int64_t>(1,(cores+groups-1)/groups));
    QliCTiling t{uint64_t(offset),uint64_t(k.stride(0)),uint64_t(ks.stride(0)),uint32_t(valid),uint32_t(cap),uint32_t(sp),uint32_t(usedk.numel()),uint32_t(table.size(1)),uint32_t(std::min<int64_t>(cores,groups*splits)),uint32_t(splits),uint32_t(nt),uint32_t(groupRows),uint32_t(std::min<int64_t>(vectorCores,cap))};
    auto stream=c10_npu::getCurrentNPUStream().stream(true);
    qli_c_a_alias4_launch(stream,q.data_ptr(),k.data_ptr(),qs.data_ptr(),ks.data_ptr(),cu.data_ptr(),usedk.data_ptr(),table.data_ptr(),out.data_ptr(),t);
    return out;
}
at::Tensor calias4(const at::Tensor& q,const at::Tensor& k,const at::Tensor& qs,const at::Tensor& ks,
 const at::Tensor& cu,const at::Tensor& usedq,const at::Tensor& usedk,const at::Tensor& table,
 int64_t offset,int64_t valid,int64_t cap) {
    TORCH_CHECK(table.dim()==2,"table rank");
    auto out=at::empty({cap,32,((table.size(1)*64+127)/128)*128},q.options().dtype(at::kBFloat16));
    return calias4_out(q,k,qs,ks,cu,usedq,usedk,table,offset,valid,cap,out);
}
TORCH_LIBRARY_FRAGMENT(qli_cv_calias4,m) {
 m.def("c(Tensor q, Tensor k, Tensor qs, Tensor ks, Tensor cu, Tensor usedq, Tensor usedk, Tensor table, int row_offset, int valid_q, int qcap) -> Tensor");
 m.def("c_out(Tensor q, Tensor k, Tensor qs, Tensor ks, Tensor cu, Tensor usedq, Tensor usedk, Tensor table, int row_offset, int valid_q, int qcap, Tensor(a!) raw_qk) -> Tensor(a!)");
}
TORCH_LIBRARY_IMPL(qli_cv_calias4,PrivateUse1,m) { m.impl("c",&calias4); m.impl("c_out",&calias4_out); }
