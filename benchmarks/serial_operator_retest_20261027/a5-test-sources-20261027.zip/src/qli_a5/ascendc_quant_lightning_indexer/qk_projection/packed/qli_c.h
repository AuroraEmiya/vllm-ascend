#pragma once
#include <cstdint>
struct QliCTiling {
    uint64_t rowOffset, kPageStrideBytes, ksPageStrideBytes;
    uint32_t validQ, qcap, sPad, batchCount, maxPages, coreCount, splits, nTiles, groupRows, padCoreCount;
    uint32_t rawLayout;
};
