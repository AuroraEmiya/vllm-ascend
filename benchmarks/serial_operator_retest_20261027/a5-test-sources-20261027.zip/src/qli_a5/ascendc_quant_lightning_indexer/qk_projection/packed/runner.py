"""Exclusive C/V QGROUP8 plan. Raw tensor shape is logical, storage may be grouped."""
from collections import namedtuple
from pathlib import Path
import torch
import torch_npu
_loaded=False
PLAN_VERSION="QLI_QGROUP8_V1"
RAW_LAYOUTS=("ND","QGROUP8_N128")
LayoutPlan=namedtuple("LayoutPlan","version qcap s_pad valid_q aiv_count raw_layout device")

def load():
    global _loaded
    if not _loaded:
        torch.ops.load_library(str(Path(__file__).parent/'build/libqli_c_a_qgroup8_pure.so'))
        _loaded=True

def make_plan(qcap,s_pad,valid_q,*,device):
    if torch.npu.is_current_stream_capturing():
        raise RuntimeError("Create shared layout plan before graph capture")
    if not 0 < valid_q <= qcap or s_pad<=0 or s_pad%128:
        raise ValueError("Invalid layout plan shape")
    load()
    with torch.npu.device(device):
        aiv,layout=torch.ops.qli_cv_cqgroup8_pure.layout_info(valid_q,s_pad)
        resolved=str(torch.device('npu',torch.npu.current_device()))
    return LayoutPlan(PLAN_VERSION,qcap,s_pad,valid_q,aiv,RAW_LAYOUTS[layout],resolved)

def validate_plan(plan,qcap,s_pad,valid_q,device):
    if (getattr(plan,'version',None)!=PLAN_VERSION or
        (plan.qcap,plan.s_pad,plan.valid_q)!=(qcap,s_pad,valid_q) or
        plan.raw_layout not in RAW_LAYOUTS or plan.device!=str(device)):
        raise ValueError("Explicit shared Qgroup8 layout plan mismatch")
    return RAW_LAYOUTS.index(plan.raw_layout)

def allocate_raw(plan,*,device):
    validate_plan(plan,plan.qcap,plan.s_pad,plan.valid_q,torch.device(device))
    return torch.empty((plan.qcap,32,plan.s_pad),dtype=torch.bfloat16,device=device)

def run(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,
        row_offset,valid_q,qcap,*,plan,out=None):
    sp=((block_table.shape[1]*64+127)//128)*128
    layout=validate_plan(plan,qcap,sp,valid_q,q.device)
    if torch.npu.is_current_stream_capturing() and (not _loaded or out is None):
        raise RuntimeError("Load and allocate raw before capture")
    load()
    args=(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,
          row_offset,valid_q,qcap,layout,plan.aiv_count)
    raw=torch.ops.qli_cv_cqgroup8_pure.c(*args) if out is None else torch.ops.qli_cv_cqgroup8_pure.c_out(*args,out)
    raw._qli_qgroup8_plan=plan
    return raw
