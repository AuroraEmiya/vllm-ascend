#include <ATen/ATen.h>
#include <torch/library.h>
#include <c10/core/DeviceGuard.h>
#include <algorithm>
#include "acl/acl.h"
static bool use_quad(const at::Tensor&q,int64_t valid,int64_t sp){
 TORCH_CHECK(q.is_privateuseone(),"NPU required");c10::DeviceGuard guard(q.device());
 TORCH_CHECK(valid>0&&valid<=UINT32_MAX&&sp>0&&sp<=32896&&sp%128==0,"shape controls");
 int32_t dev=-1;int64_t cores=0;
 TORCH_CHECK(aclrtGetDevice(&dev)==ACL_SUCCESS,"device query");
 TORCH_CHECK(aclrtGetDeviceInfo(dev,ACL_DEV_ATTR_CUBE_CORE_NUM,&cores)==ACL_SUCCESS&&cores>0,"actual Cube query");
 int64_t limit=std::min<int64_t>(16,std::max<int64_t>(1,valid/cores)),g=1,nt=(sp+255)/256;
 while(g*2<=limit)g*=2;
 if(g==1&&valid>=2&&uint64_t((valid+1)/2)*uint64_t(nt)>=uint64_t(cores))g=2;
 bool potential=g<=2&&valid>=4&&uint64_t((valid+3)/4)*uint64_t(nt)>=uint64_t(cores);
 if(!potential)return false;
 int64_t groups4=(valid+3)/4,splits4=std::min<int64_t>(nt,std::max<int64_t>(1,(cores+groups4-1)/groups4));
 return nt/splits4>=4;
}
TORCH_LIBRARY_FRAGMENT(qli_cv_calias4_long,m){m.def("use_quad(Tensor q, int valid_q, int s_pad) -> bool");}
TORCH_LIBRARY_IMPL(qli_cv_calias4_long,PrivateUse1,m){m.impl("use_quad",&use_quad);}
