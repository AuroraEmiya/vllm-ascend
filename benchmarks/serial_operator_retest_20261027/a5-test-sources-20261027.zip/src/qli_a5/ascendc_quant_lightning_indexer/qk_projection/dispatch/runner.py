"""Experimental host dispatch to frozen pair/quad libraries; no new kernel."""
from pathlib import Path
import importlib.util
import sys
import torch
import torch_npu
_loaded=False
_pair=None
_quad=None
def _load_runner(name):
    key='_qli_alias4_long_'+name
    if key in sys.modules:return sys.modules[key]
    path=Path(__file__).resolve().parent.parent/name/'runner.py'
    spec=importlib.util.spec_from_file_location(key,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[key]=mod
    spec.loader.exec_module(mod)
    return mod
def load():
    global _loaded,_pair,_quad
    if _loaded:return
    if torch.npu.is_current_stream_capturing():raise RuntimeError('Preload selector and dependencies before capture')
    _pair=_load_runner('pair');_quad=_load_runner('quad')
    _pair.load();_quad.load()
    torch.ops.load_library(str(Path(__file__).parent/'build/libqli_c_a_alias4_long.so'))
    _loaded=True
def run(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,row_offset,valid_q,qcap,*,out=None):
    if torch.npu.is_current_stream_capturing() and (not _loaded or out is None):
        raise RuntimeError('Preload all libraries and provide out before capture')
    load()
    if block_table.ndim!=2:raise ValueError('block table rank')
    sp=((block_table.shape[1]*64+127)//128)*128
    target=_quad if torch.ops.qli_cv_calias4_long.use_quad(q,valid_q,sp) else _pair
    return target.run(q,k,q_descale,k_descale,cu_seqlens_q,seqused_q,seqused_k,block_table,row_offset,valid_q,qcap,out=out)
