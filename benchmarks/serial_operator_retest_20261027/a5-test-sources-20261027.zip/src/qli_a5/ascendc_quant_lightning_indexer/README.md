# Ascend C Quant Lightning Indexer

A5量化Lightning Indexer最终源码。框架使用统一入口，内部串行执行QK投影与稀疏选择。

## 构建

原验证环境：DAV_3510 / CANN9.3.0 / Python3.11.10与对应torch、torch_npu。
```bash
source /usr/local/Ascend/cann/set_env.sh
bash build.sh
```
将本目录父路径加入PYTHONPATH。内部五个SO保留原注册名，以保持原生代码与已测版本一致；无需框架分别接入。
不包含SDK、动态库或部署注册。CANN/torch版本变化需要重新验证。

## 普通调用

```python
from ascendc_quant_lightning_indexer import quant_lightning_indexer
outputs = quant_lightning_indexer(
    q, k, w, q_descale, k_descale,
    cu_seqlens_q=cu_seqlens_q, seqused_q=seqused_q,
    seqused_k=seqused_k, block_table=block_table,
    candidate_topk_blocks=2048, candidate_block_size=8,
)
```
自动按1024 query切分并填满所有输出行，尾chunk自动处理。
这是本包的新Python接口，不是基线A/B的全部参数兼容替代；未支持的选项不能直接传入。

## 图模式与重复调用

```python
import torch, torch_npu
from ascendc_quant_lightning_indexer import prepare_quant_lightning_indexer
op = prepare_quant_lightning_indexer(
    q, k, w, q_descale, k_descale,
    cu_seqlens_q=cu_seqlens_q, seqused_q=seqused_q,
    seqused_k=seqused_k, block_table=block_table,
    candidate_topk_blocks=-1, candidate_block_size=-1,
)
outputs = op.run()  # 捕图前预热
# 在输入所在设备、同一stream完成预热、捕图及后续replay。
torch.npu.synchronize()
graph = torch.npu.NPUGraph()
with torch.npu.graph(graph):
    outputs = op.run()
graph.replay()
```
prepare必须在捕图外，负责加载库、创建layout plan、分配raw/workspace/output。
普通quant_lightning_indexer入口会准备内存，禁止在捕图中调用；捕图使用op.run。
保留op及所有输入存储至执行完成。输入只可原位更新且保持shape/布局/请求metadata合法，替换tensor必须重新prepare/捕图。
输出缓冲区每次run/replay复用；需保存快照请自行复制。一个op不能跨stream并发；并发使用独立实例。

## 输入合同

- q:uint8[T,32,64]、k:uint8[P,64,1,64]，packed MXFP4。
- q_descale:uint8[T,32,2,2]、k_descale:uint8[P,64,1,2,2]，E8M0载体。
- w:float32[T,32]。
- cu_seqlens_q:int32[B+1]，seqused_q/seqused_k:int32[B]，block_table:int32[B,pages]；均同NPU且连续。
- 请求前缀、有效长度、页表索引须合法，不能超过Q/K存储或声明容量；本接口不从设备复制metadata到CPU做逐值扫描。
- 固定32 heads，D=128，TopK512，非空T；S_pad=ceil(pages*64/128)*128<=32896。
- candidate配置仅支持off=(-1,-1)、on=(2048,8)。quant_mode=1、mask_mode=3、cmp_ratio=1、TND/PA_BBND语义固定。
- 输出tuple：sparse_indices int32[T,1,512]、sparse_values BF16[T,1,512]、candidate_indices int32[T,1,2048]、candidate_length int32[T,1]；off后两项为空。

## 分阶段接口

compute_qk_scores与select_sparse_indices供明确需要分阶段的接入方使用，签名与内部runner.run一致；完整框架接入优先统一入口。
C产生完整signed BF16 raw，V做ReLU、按head顺序BF16加权FMA及TopK。内部raw可能packed，禁止当普通ND解释或单边替换布局。
qk_projection的packed/pair/quad/dispatch均为最终依赖；sparse_selection含四类tiling。

## 本次检查范围

新入口通过20组CPU模拟调度场景（candidate开关、单chunk/整chunk/多chunk/奇数尾部）、重复调用、捕图准备拒绝及非法参数检查。
39个原生/构建文件与原最终版本字节一致。新的Python入口尚未在NPU运行：当前远端容器停止，未擅自重启。
历史最终kernel已通过完整12例正确性，但不将历史结果冒充新入口上板结果。接入环境仍需先做小例及graph replay验证。
完整设计、性能和数值验证材料保留在上次交付目录/远端交接包，本源码包不重复携带。
