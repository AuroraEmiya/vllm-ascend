/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#pragma once
#include "a_vector_base.h"
constexpr uint32_t UB_BANK_DEPTH_STRIDE=1024;
__simd_callee__ inline void CastWeightToBf16(AscendC::Reg::RegTensor<bfloat16_t> &dst, __ubuf__ float *src,
                                             AscendC::Reg::MaskReg &maskAllB32)
{
    using CastTrait = AscendC::Reg::CastTrait;
    static constexpr CastTrait castTraitF32ToBf16 = {AscendC::Reg::RegLayout::ZERO, AscendC::Reg::SatMode::NO_SAT,
                                                     AscendC::Reg::MaskMergeMode::ZEROING, RoundMode::CAST_RINT};
    AscendC::Reg::RegTensor<float> regWeightF32;
    AscendC::Reg::LoadAlign<float>(regWeightF32, src);
    AscendC::Reg::Cast<bfloat16_t, float, castTraitF32ToBf16>(dst, regWeightF32, maskAllB32);
    // Cast结果按B32 lane落位，在目标寄存器内压紧为连续BF16，供BroadcastLane按元素索引。
    AscendC::Reg::Pack<uint16_t, uint32_t, AscendC::Reg::HighLowPart::LOWEST>((AscendC::Reg::RegTensor<uint16_t> &)dst,
                                                                              (AscendC::Reg::RegTensor<uint32_t> &)dst);
}

__simd_vf__ void MulWeightAndReduceSumMXFP4VF(__ubuf__ uint16_t *out, __ubuf__ bfloat16_t *qk, __ubuf__ float *weight,
                                              uint16_t gSize, uint32_t count0, uint32_t count1)
{
    constexpr uint32_t BF16_QK_ROW_STRIDE = UB_BANK_DEPTH_STRIDE / sizeof(bfloat16_t);
    AscendC::Reg::RegTensor<bfloat16_t> regQK;
    AscendC::Reg::RegTensor<bfloat16_t> regWeight;
    AscendC::Reg::RegTensor<bfloat16_t> regWeightBrc;
    AscendC::Reg::RegTensor<bfloat16_t> regSum;
    AscendC::Reg::MaskReg maskAllB16 = AscendC::Reg::CreateMask<bfloat16_t, AscendC::Reg::MaskPattern::ALL>();
    AscendC::Reg::MaskReg maskAllB32 = AscendC::Reg::CreateMask<float, AscendC::Reg::MaskPattern::ALL>();

    liV2Vector1::FloatSortConstCtx<bfloat16_t> bf16Ctx;
    liV2Vector1::InitFloatSortConstCtx(bf16Ctx, maskAllB16);

    CastWeightToBf16(regWeight, weight, maskAllB32);
    AscendC::Reg::Duplicate(regSum, bfloat16_t(0.0f), maskAllB16);

    for (uint16_t i = 0; i < gSize; i++) {
        AscendC::Reg::LoadAlign<bfloat16_t>(regQK, qk + BF16_QK_ROW_STRIDE * i);
        AscendC::Reg::Maxs(regQK, regQK, bfloat16_t(0.0f), maskAllB16);
        liV2Vector1::BroadcastLane(regWeightBrc, regWeight, i);
        AscendC::Reg::MulAddDst(regSum, regQK, regWeightBrc, maskAllB16);
    }

    AscendC::Reg::RegTensor<uint16_t> regOut;
    AscendC::Reg::Adds(regSum,regSum,bfloat16_t(0.0f),maskAllB16);
    liV2Vector1::FloatToSortableKey<bfloat16_t>(regOut, regSum, bf16Ctx, maskAllB16);
    auto valid0=AscendC::Reg::UpdateMask<uint16_t>(count0);
    AscendC::Reg::StoreAlign<uint16_t, AscendC::Reg::StoreDist::DIST_NORM>(out, regOut, valid0);
}

__simd_vf__ void MulWeightAndReduceSumMXFP4TwoRowsVF(__ubuf__ uint16_t *out0, __ubuf__ uint16_t *out1,
                                                     __ubuf__ bfloat16_t *qk0, __ubuf__ bfloat16_t *qk1,
                                                     __ubuf__ float *weight0, __ubuf__ float *weight1, uint16_t gSize, uint32_t count0, uint32_t count1)
{
    constexpr uint32_t BF16_QK_ROW_STRIDE = UB_BANK_DEPTH_STRIDE / sizeof(bfloat16_t);
    AscendC::Reg::RegTensor<bfloat16_t> regQK0;
    AscendC::Reg::RegTensor<bfloat16_t> regQK1;
    AscendC::Reg::RegTensor<bfloat16_t> regWeight[2];
    AscendC::Reg::RegTensor<bfloat16_t> regWeightBrc[2];
    AscendC::Reg::RegTensor<bfloat16_t> regSum[2];
    AscendC::Reg::MaskReg maskAllB16 = AscendC::Reg::CreateMask<bfloat16_t, AscendC::Reg::MaskPattern::ALL>();
    AscendC::Reg::MaskReg maskAllB32 = AscendC::Reg::CreateMask<float, AscendC::Reg::MaskPattern::ALL>();

    liV2Vector1::FloatSortConstCtx<bfloat16_t> bf16Ctx;
    liV2Vector1::InitFloatSortConstCtx(bf16Ctx, maskAllB16);

    CastWeightToBf16(regWeight[0], weight0, maskAllB32);
    CastWeightToBf16(regWeight[1], weight1, maskAllB32);
    AscendC::Reg::Duplicate(regSum[0], bfloat16_t(0.0f), maskAllB16);
    AscendC::Reg::Duplicate(regSum[1], bfloat16_t(0.0f), maskAllB16);

    for (uint16_t i = 0; i < gSize; i++) {
        AscendC::Reg::LoadAlign<bfloat16_t>(regQK0, qk0 + BF16_QK_ROW_STRIDE * i);
        AscendC::Reg::LoadAlign<bfloat16_t>(regQK1, qk1 + BF16_QK_ROW_STRIDE * i);
        AscendC::Reg::Maxs(regQK0, regQK0, bfloat16_t(0.0f), maskAllB16);
        AscendC::Reg::Maxs(regQK1, regQK1, bfloat16_t(0.0f), maskAllB16);
        liV2Vector1::BroadcastLane(regWeightBrc[0], regWeight[0], i);
        liV2Vector1::BroadcastLane(regWeightBrc[1], regWeight[1], i);
        AscendC::Reg::MulAddDst(regSum[0], regQK0, regWeightBrc[0], maskAllB16);
        AscendC::Reg::MulAddDst(regSum[1], regQK1, regWeightBrc[1], maskAllB16);
    }

    AscendC::Reg::RegTensor<uint16_t> regOut[2];
    AscendC::Reg::Adds(regSum[0],regSum[0],bfloat16_t(0.0f),maskAllB16);
    AscendC::Reg::Adds(regSum[1],regSum[1],bfloat16_t(0.0f),maskAllB16);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(regOut[0], regOut[1], regSum[0], regSum[1], bf16Ctx, maskAllB16);
    auto valid0=AscendC::Reg::UpdateMask<uint16_t>(count0);
    auto valid1=AscendC::Reg::UpdateMask<uint16_t>(count1);
    AscendC::Reg::StoreAlign<uint16_t, AscendC::Reg::StoreDist::DIST_NORM>(out0, regOut[0], valid0);
    AscendC::Reg::StoreAlign<uint16_t, AscendC::Reg::StoreDist::DIST_NORM>(out1, regOut[1], valid1);
}

