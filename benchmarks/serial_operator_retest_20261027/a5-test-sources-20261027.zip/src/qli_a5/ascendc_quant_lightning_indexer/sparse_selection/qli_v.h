#pragma once
#include <cstdint>
struct QliVTiling {
    uint64_t rowOffset;
    uint32_t validQ, qcap, sPad, batchCount, coreCount, candidate;
    uint32_t family, shards, candidateCapacity;
    uint32_t rawLayout;
    uint32_t shardSpan; // private ABI:16384 except balanced family3
};
