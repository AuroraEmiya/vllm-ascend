#pragma once
// Pair512: each explicit accumulator retains BF16 head0..31 order.
template<bool TwoRows>
__simd_vf__ void ScorePair512VF(__ubuf__ uint16_t* out,__ubuf__ bfloat16_t* raw,
    __ubuf__ float* weights,uint32_t len0,uint32_t len1,uint32_t tiles){
    auto all=Reg::CreateMask<bfloat16_t,Reg::MaskPattern::ALL>();
    auto mf=Reg::CreateMask<float,Reg::MaskPattern::ALL>();
    Reg::RegTensor<bfloat16_t> w0,w1,brc,q,s00,s01,s02,s03,s10,s11,s12,s13;
    CastWeightToBf16(w0,weights,mf);
    if constexpr(TwoRows) CastWeightToBf16(w1,weights+32,mf);
    constexpr uint32_t stride=TwoRows?8192:4096;
    uint32_t off1=tiles>=2?stride:0,off2=tiles>=3?2*stride:0,off3=tiles>=4?3*stride:0;
    Reg::Duplicate(s00,bfloat16_t(0.0f),all);
    Reg::Duplicate(s01,bfloat16_t(0.0f),all);
    Reg::Duplicate(s02,bfloat16_t(0.0f),all);
    Reg::Duplicate(s03,bfloat16_t(0.0f),all);
    if constexpr(TwoRows){
    Reg::Duplicate(s10,bfloat16_t(0.0f),all);
    Reg::Duplicate(s11,bfloat16_t(0.0f),all);
    Reg::Duplicate(s12,bfloat16_t(0.0f),all);
    Reg::Duplicate(s13,bfloat16_t(0.0f),all);
    }
    for(uint16_t h=0;h<32;h++){
        liV2Vector1::BroadcastLane(brc,w0,h);
        Reg::LoadAlign(q,raw+0+h*128+0);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s00,q,brc,all);
        Reg::LoadAlign(q,raw+0+h*128+off1);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s01,q,brc,all);
        Reg::LoadAlign(q,raw+0+h*128+off2);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s02,q,brc,all);
        Reg::LoadAlign(q,raw+0+h*128+off3);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s03,q,brc,all);
        if constexpr(TwoRows){
        liV2Vector1::BroadcastLane(brc,w1,h);
        Reg::LoadAlign(q,raw+4096+h*128+0);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s10,q,brc,all);
        Reg::LoadAlign(q,raw+4096+h*128+off1);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s11,q,brc,all);
        Reg::LoadAlign(q,raw+4096+h*128+off2);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s12,q,brc,all);
        Reg::LoadAlign(q,raw+4096+h*128+off3);
        Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s13,q,brc,all);
        }
    }
    liV2Vector1::FloatSortConstCtx<bfloat16_t> ctx;
    liV2Vector1::InitFloatSortConstCtx(ctx,all);
    Reg::RegTensor<uint16_t> k0,k1;
    Reg::Adds(s00,s00,bfloat16_t(0.0f),all);
    Reg::Adds(s01,s01,bfloat16_t(0.0f),all);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(k0,k1,s00,s01,ctx,all);
    uint32_t n00=len0>0?(len0-0<128?len0-0:128):0;
    auto m00=Reg::UpdateMask<uint16_t>(n00);
    Reg::StoreAlign(out+0,k0,m00);
    uint32_t n01=len0>128?(len0-128<128?len0-128:128):0;
    auto m01=Reg::UpdateMask<uint16_t>(n01);
    Reg::StoreAlign(out+128,k1,m01);
    Reg::Adds(s02,s02,bfloat16_t(0.0f),all);
    Reg::Adds(s03,s03,bfloat16_t(0.0f),all);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(k0,k1,s02,s03,ctx,all);
    uint32_t n02=len0>256?(len0-256<128?len0-256:128):0;
    auto m02=Reg::UpdateMask<uint16_t>(n02);
    Reg::StoreAlign(out+256,k0,m02);
    uint32_t n03=len0>384?(len0-384<128?len0-384:128):0;
    auto m03=Reg::UpdateMask<uint16_t>(n03);
    Reg::StoreAlign(out+384,k1,m03);
    if constexpr(TwoRows){
    Reg::Adds(s10,s10,bfloat16_t(0.0f),all);
    Reg::Adds(s11,s11,bfloat16_t(0.0f),all);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(k0,k1,s10,s11,ctx,all);
    uint32_t n10=len1>0?(len1-0<128?len1-0:128):0;
    auto m10=Reg::UpdateMask<uint16_t>(n10);
    Reg::StoreAlign(out+1024,k0,m10);
    uint32_t n11=len1>128?(len1-128<128?len1-128:128):0;
    auto m11=Reg::UpdateMask<uint16_t>(n11);
    Reg::StoreAlign(out+1152,k1,m11);
    Reg::Adds(s12,s12,bfloat16_t(0.0f),all);
    Reg::Adds(s13,s13,bfloat16_t(0.0f),all);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(k0,k1,s12,s13,ctx,all);
    uint32_t n12=len1>256?(len1-256<128?len1-256:128):0;
    auto m12=Reg::UpdateMask<uint16_t>(n12);
    Reg::StoreAlign(out+1280,k0,m12);
    uint32_t n13=len1>384?(len1-384<128?len1-384:128):0;
    auto m13=Reg::UpdateMask<uint16_t>(n13);
    Reg::StoreAlign(out+1408,k1,m13);
    }
}
