"""Independent raw-BF16 V; load and allocate outputs before graph capture."""
from pathlib import Path
import torch
import torch_npu
_loaded=False
def load():
    global _loaded
    if not _loaded:
        torch.ops.load_library(str(Path(__file__).parent/'build/libqli_v_a_pair512_contiguous.so'))
        _loaded=True
def allocate_outputs(raw_qk,valid_q,candidate_topk_blocks):
    kw={'device':raw_qk.device}
    si=torch.empty((valid_q,1,512),dtype=torch.int32,**kw)
    sv=torch.empty((valid_q,1,512),dtype=torch.bfloat16,**kw)
    if candidate_topk_blocks==2048:
        ci=torch.empty((valid_q,1,2048),dtype=torch.int32,**kw)
        clen=torch.empty((valid_q,1),dtype=torch.int32,**kw)
    else:
        ci=torch.empty(0,dtype=torch.int32,**kw)
        clen=torch.empty(0,dtype=torch.int32,**kw)
    return si,sv,ci,clen
def allocate_workspace(raw_qk, query_capacity, candidate_topk_blocks):
    if torch.npu.is_current_stream_capturing():
        raise RuntimeError("Allocate workspace before graph capture")
    if not 0 < query_capacity <= raw_qk.shape[0]:
        raise ValueError("workspace query capacity")
    sp = raw_qk.shape[2]
    # Reserve4; kernels pack active rows with stride(active_shards*512).
    # Inactive capacity is never read, allowing3/4-shard chunks to reuse storage.
    shape = (query_capacity, 4, 512) if sp > 16384 else (0,)
    nc = ((sp + 7) // 8 + 255) // 256 * 256
    cshape = (query_capacity, nc) if sp > 16384 and candidate_topk_blocks == 2048 else (0,)
    return (torch.empty(shape, dtype=torch.int16, device=raw_qk.device),
            torch.empty(shape, dtype=torch.int32, device=raw_qk.device),
            torch.empty(cshape, dtype=torch.int16, device=raw_qk.device))

def run_v(raw_qk,w,cu_seqlens_q,seqused_q,seqused_k,block_table,row_offset,valid_q,
          candidate_topk_blocks,candidate_block_size,*,plan,out=None,workspace=None):
    layouts=("ND","QGROUP8_N128")
    if (getattr(plan,'version',None)!="QLI_QGROUP8_V1" or
        (plan.qcap,plan.s_pad,plan.valid_q)!=(raw_qk.shape[0],raw_qk.shape[2],valid_q) or
        plan.raw_layout not in layouts or plan.device!=str(raw_qk.device)):
        raise ValueError("Explicit shared Qgroup8 layout plan mismatch")
    if getattr(raw_qk,'_qli_qgroup8_plan',None)!=plan:
        raise ValueError("Raw was produced with another layout plan")
    layout=layouts.index(plan.raw_layout)
    if torch.npu.is_current_stream_capturing() and (not _loaded or out is None or workspace is None):
        raise RuntimeError("Load library and allocate outputs/workspace before graph capture")
    load()
    if out is None:
        out=allocate_outputs(raw_qk,valid_q,candidate_topk_blocks)
    if workspace is None:
        workspace=allocate_workspace(raw_qk,valid_q,candidate_topk_blocks)
    torch.ops.qli_cv_a_pair512_contiguous.v_out(raw_qk,w,cu_seqlens_q,seqused_q,seqused_k,block_table,
                         row_offset,valid_q,candidate_topk_blocks,candidate_block_size,layout,plan.aiv_count,*out,*workspace)
    return out
run=run_v
