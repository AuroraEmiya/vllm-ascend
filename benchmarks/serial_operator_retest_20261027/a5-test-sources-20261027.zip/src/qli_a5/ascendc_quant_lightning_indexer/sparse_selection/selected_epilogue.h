#pragma once
// Fixed 512 valid outputs. Gather and index widening preserve A's selected order.
__simd_vf__ void Selected512EpilogueVF(__ubuf__ uint32_t* outIdx,
    __ubuf__ uint16_t* outValue,__ubuf__ uint16_t* keys,__ubuf__ uint16_t* selected){
    auto all=Reg::CreateMask<uint16_t,Reg::MaskPattern::ALL>();
    auto all32=Reg::CreateMask<uint32_t,Reg::MaskPattern::ALL>();
    Reg::RegTensor<uint16_t> sign,ones;
    Reg::Duplicate(sign,uint16_t(0x8000),all);Reg::Duplicate(ones,uint16_t(0xffff),all);
    for(uint16_t i=0;i<4;i++){
        Reg::RegTensor<uint16_t> idx,k,test,pos,neg,bits,wide0,wide1;
        Reg::LoadAlign<uint16_t,Reg::LoadDist::DIST_NORM>(idx,selected+i*128);
        Reg::Gather(k,keys,idx,all);
        Reg::And(test,k,sign,all);
        Reg::MaskReg positive;Reg::Compare<uint16_t,CMPMODE::EQ>(positive,test,sign,all);
        Reg::Xor(pos,k,sign,all);Reg::Xor(neg,k,ones,all);
        Reg::Select(bits,pos,neg,positive);
        Reg::StoreAlign<uint16_t,Reg::StoreDist::DIST_NORM>(outValue+i*128,bits,all);
        Reg::LoadAlign<uint16_t,Reg::LoadDist::DIST_UNPACK_B16>(wide0,selected+i*128);
        Reg::LoadAlign<uint16_t,Reg::LoadDist::DIST_UNPACK_B16>(wide1,selected+i*128+64);
        Reg::StoreAlign<uint32_t,Reg::StoreDist::DIST_NORM>(outIdx+i*128,(Reg::RegTensor<uint32_t>&)wide0,all32);
        Reg::StoreAlign<uint32_t,Reg::StoreDist::DIST_NORM>(outIdx+i*128+64,(Reg::RegTensor<uint32_t>&)wide1,all32);
    }
}
