#pragma once
// New scheduling adapter; A CastWeightToBf16/BroadcastLane/key helpers retained.
template<bool TwoRows>
__simd_vf__ void Score256VF(__ubuf__ uint16_t* out0,__ubuf__ uint16_t* out1,
    __ubuf__ bfloat16_t* qk,__ubuf__ float* weights,uint32_t c0,uint32_t c1){
    auto all=Reg::CreateMask<bfloat16_t,Reg::MaskPattern::ALL>();
    auto mf=Reg::CreateMask<float,Reg::MaskPattern::ALL>();
    Reg::RegTensor<bfloat16_t> w0,w1,brc,q,s00,s01,s10,s11;
    CastWeightToBf16(w0,weights,mf);
    if constexpr(TwoRows)CastWeightToBf16(w1,weights+128,mf);
    Reg::Duplicate(s00,bfloat16_t(0.0f),all);Reg::Duplicate(s01,bfloat16_t(0.0f),all);
    if constexpr(TwoRows){Reg::Duplicate(s10,bfloat16_t(0.0f),all);Reg::Duplicate(s11,bfloat16_t(0.0f),all);}
    for(uint16_t h=0;h<32;h++){
        liV2Vector1::BroadcastLane(brc,w0,h);
        Reg::LoadAlign(q,qk+h*512);Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s00,q,brc,all);
        Reg::LoadAlign(q,qk+h*512+128);Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s01,q,brc,all);
        if constexpr(TwoRows){
            liV2Vector1::BroadcastLane(brc,w1,h);
            Reg::LoadAlign(q,qk+16384+h*512);Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s10,q,brc,all);
            Reg::LoadAlign(q,qk+16384+h*512+128);Reg::Maxs(q,q,bfloat16_t(0.0f),all);Reg::MulAddDst(s11,q,brc,all);
        }
    }
    liV2Vector1::FloatSortConstCtx<bfloat16_t> ctx;
    liV2Vector1::InitFloatSortConstCtx(ctx,all);
    Reg::RegTensor<uint16_t> key0,key1;
    Reg::Adds(s00,s00,bfloat16_t(0.0f),all);Reg::Adds(s01,s01,bfloat16_t(0.0f),all);
    liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(key0,key1,s00,s01,ctx,all);
    uint32_t low0=c0<128?c0:128,high0=c0>128?c0-128:0;
    auto m00=Reg::UpdateMask<uint16_t>(low0),m01=Reg::UpdateMask<uint16_t>(high0);
    Reg::StoreAlign(out0,key0,m00);Reg::StoreAlign(out0+128,key1,m01);
    if constexpr(TwoRows){
        Reg::Adds(s10,s10,bfloat16_t(0.0f),all);Reg::Adds(s11,s11,bfloat16_t(0.0f),all);
        liV2Vector1::FloatX2ToSortableKey<bfloat16_t>(key0,key1,s10,s11,ctx,all);
        uint32_t low1=c1<128?c1:128,high1=c1>128?c1-128:0;
        auto m10=Reg::UpdateMask<uint16_t>(low1),m11=Reg::UpdateMask<uint16_t>(high1);
        Reg::StoreAlign(out1,key0,m10);Reg::StoreAlign(out1+128,key1,m11);
    }
}
