#include <ATen/ATen.h>
#include <algorithm>
#include <climits>
#include <torch/library.h>
#include <c10/core/DeviceGuard.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "acl/acl.h"
#include "qli_v.h"
extern "C" void qli_v_a_pair512_contiguous_launch(aclrtStream,void*,void*,void*,void*,void*,void*,void*,void*,void*,void*,void*,void*,QliVTiling);
static void check(const at::Tensor& x,const at::Tensor& raw,at::ScalarType dt,const char* n) {
 TORCH_CHECK(x.device()==raw.device() && x.scalar_type()==dt && x.is_contiguous(),n," dtype/device/stride mismatch");
}
void v_pair512_contiguous_out(const at::Tensor& raw,const at::Tensor& w,const at::Tensor& cu,const at::Tensor& uq,
 const at::Tensor& uk,const at::Tensor& table,int64_t offset,int64_t valid,int64_t candidate,int64_t block,int64_t rawLayout,int64_t plannedAiv,
 at::Tensor si,at::Tensor sv,at::Tensor ci,at::Tensor len,at::Tensor pk,at::Tensor pi,at::Tensor ck) {
 TORCH_CHECK(raw.is_privateuseone(),"NPU required"); c10::DeviceGuard guard(raw.device());
 check(raw,raw,at::kBFloat16,"raw_qk"); check(w,raw,at::kFloat,"weight");
 for(auto x:{cu,uq,uk,table}) check(x,raw,at::kInt,"metadata");
 TORCH_CHECK(raw.dim()==3 && raw.size(1)==32 && raw.size(2)>0 && raw.size(2)%128==0 && raw.size(2)<=32896,"raw Qcap/32/S_pad ABI");
 TORCH_CHECK(valid>0 && valid<=raw.size(0) && offset>=0 && offset+valid<=INT32_MAX,"invalid chunk controls");
 TORCH_CHECK(w.dim()==2 && w.size(0)==valid && w.size(1)==32,"local w view shape");
 TORCH_CHECK(cu.dim()==1 && uq.dim()==1 && uk.dim()==1 && uq.numel()==uk.numel() && cu.numel()==uk.numel()+1 && table.dim()==2 && table.size(0)==uk.numel() && table.size(1)>0,"metadata shape");
 TORCH_CHECK(raw.size(2)==((table.size(1)*64+127)/128)*128,"S_pad must match block table capacity");
 bool on=candidate==2048 && block==8;
 TORCH_CHECK(on || (candidate==-1 && block==-1),"supported candidate configs: -1/-1 or 2048/8");
 check(si,raw,at::kInt,"sparse indices"); check(sv,raw,at::kBFloat16,"sparse values");
 check(ci,raw,at::kInt,"candidate indices"); check(len,raw,at::kInt,"candidate length");
 TORCH_CHECK(si.sizes()==at::IntArrayRef({valid,1,512}) && sv.sizes()==si.sizes(),"sparse output views");
 TORCH_CHECK(on ? (ci.sizes()==at::IntArrayRef({valid,1,2048}) && len.sizes()==at::IntArrayRef({valid,1})) : (ci.numel()==0 && len.numel()==0),"candidate output views");
 int32_t dev=-1; int64_t cores=0;
 TORCH_CHECK(aclrtGetDevice(&dev)==ACL_SUCCESS,"device query");
 TORCH_CHECK(aclrtGetDeviceInfo(dev,ACL_DEV_ATTR_VECTOR_CORE_NUM,&cores)==ACL_SUCCESS && cores>0,"Vector count query");
 uint32_t sp=uint32_t(raw.size(2));
 TORCH_CHECK(plannedAiv==cores && rawLayout==int64_t(sp>512 && sp<=1024 && valid>=2*cores),"shared raw layout plan mismatch");
 uint32_t family=rawLayout ? 4 : (sp>16384 ? 3 : (valid>=2*cores ? 2 : 1));
 uint32_t shards=(sp+16383)/16384,shardSpan=16384;
 if(family==3 && uint64_t(valid)*shards<uint64_t(cores) && uint64_t(valid)*4<=uint64_t(cores)){
   shards=4;shardSpan=((uint32_t((sp+3)/4)+127)/128)*128;
 }
 uint32_t nc=((sp+7)/8+255)/256*256;
 check(pk,raw,at::kShort,"partial keys"); check(pi,raw,at::kInt,"partial indices");
 check(ck,raw,at::kShort,"candidate keys");
 if (family==3) {
   TORCH_CHECK(pk.dim()==3 && pk.size(0)>=valid && pk.size(1)==4 && pk.size(2)==512 && pi.sizes()==pk.sizes(),"partial workspace reserves4 shards");
   TORCH_CHECK(uint64_t(pk.numel())>=uint64_t(valid)*shards*512,"active packed partial capacity");
   TORCH_CHECK(on ? (ck.dim()==2 && ck.size(0)>=valid && ck.size(1)==nc) : ck.numel()==0,"candidate workspace shape");
 } else {
   TORCH_CHECK(pk.numel()==0 && pi.numel()==0 && ck.numel()==0,"short workspace must be empty");
 }

 uint32_t tasks=(family==2||family==4) ? uint32_t((valid+1)/2) : uint32_t(valid*shards);
 QliVTiling t{uint64_t(offset),uint32_t(valid),uint32_t(raw.size(0)),sp,uint32_t(uk.numel()),uint32_t(std::min<int64_t>(cores,tasks)),uint32_t(on),family,shards,nc,uint32_t(rawLayout),shardSpan};
 auto stream=c10_npu::getCurrentNPUStream().stream(true);
 qli_v_a_pair512_contiguous_launch(stream,raw.data_ptr(),w.data_ptr(),cu.data_ptr(),uq.data_ptr(),uk.data_ptr(),si.data_ptr(),sv.data_ptr(),ci.data_ptr(),len.data_ptr(),pk.data_ptr(),pi.data_ptr(),ck.data_ptr(),t);
}
TORCH_LIBRARY_FRAGMENT(qli_cv_a_pair512_contiguous,m) {
 m.def("v_out(Tensor raw_qk, Tensor w, Tensor cu_seqlens_q, Tensor seqused_q, Tensor seqused_k, Tensor block_table, int row_offset, int valid_q, int candidate_topk_blocks, int candidate_block_size, int raw_layout, int planned_aiv, Tensor(a!) sparse_indices, Tensor(b!) sparse_values, Tensor(c!) candidate_indices, Tensor(d!) candidate_length, Tensor(e!) partial_keys, Tensor(f!) partial_indices, Tensor(g!) candidate_keys) -> ()");
}
TORCH_LIBRARY_IMPL(qli_cv_a_pair512_contiguous,PrivateUse1,m) {m.impl("v_out",&v_pair512_contiguous_out);}
