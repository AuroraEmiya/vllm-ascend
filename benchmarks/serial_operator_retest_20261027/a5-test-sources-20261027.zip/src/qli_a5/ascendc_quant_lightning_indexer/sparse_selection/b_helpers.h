#pragma once
// B candidate and output-normalization adapters, retained from validated V1024.
__simd_vf__ void CandidateVF(__ubuf__ uint16_t* dst,__ubuf__ uint16_t* keys,uint32_t len) {
    // 128 source tokens -> 16 complete/partial candidate blocks.
    auto all=Reg::CreateMask<uint16_t,Reg::MaskPattern::ALL>();
    for (uint16_t tile=0;tile<(len+127)/128;tile++) {
        uint32_t blocks=(len-tile*128+7)/8;
        if (blocks>16) blocks=16;
        auto mask=Reg::UpdateMask<uint16_t>(blocks);
        Reg::RegTensor<int16_t> ar;
        Reg::Arange(ar,0);
        auto idx=(Reg::RegTensor<uint16_t>&)ar;
        Reg::ShiftLefts(idx,idx,int16_t(3),all);
        Reg::RegTensor<uint16_t> best,v,ix;
        Reg::Duplicate(best,uint16_t(0),all);
        for (uint16_t r=0;r<8;r++) {
            Reg::Adds(ix,idx,r,all);
            Reg::Gather(v,keys+tile*128,ix,mask);
            Reg::Max(best,best,v,mask);
        }
        Reg::StoreAlign(dst+tile*16,best,mask);
    }
}

__simd_vf__ void IndicesVF(__ubuf__ int32_t* dst,__ubuf__ uint16_t* chosen,
                         uint32_t count,uint32_t capacity,bool direct) {
    auto all=Reg::CreateMask<uint32_t,Reg::MaskPattern::ALL>();
    Reg::RegTensor<int32_t> pad;
    Reg::Duplicate(pad,int32_t(-1),all);
    for(uint16_t t=0;t<capacity/64;t++) {
        Reg::RegTensor<int32_t> index,ar;
        Reg::Arange(ar,t*64);
        if(direct) { index=ar; }
        else {
            // DIST_UNPACK_B16 ZERO extends uint16 bits; indices >=32768 stay positive.
            Reg::RegTensor<uint16_t> compact;
            Reg::LoadAlign<uint16_t,Reg::LoadDist::DIST_UNPACK_B16>(compact,chosen+t*64);
            index=(Reg::RegTensor<int32_t>&)compact;
        }
        Reg::MaskReg valid;
        Reg::Compares<int32_t,CMPMODE::LT>(valid,ar,int32_t(count),all);
        Reg::Select(index,index,pad,valid);
        Reg::StoreAlign(dst+t*64,index,all);
    }
}

__simd_vf__ void ValuesVF(__ubuf__ uint16_t* dst,__ubuf__ uint16_t* keys,uint32_t count) {
    auto all=Reg::CreateMask<uint16_t,Reg::MaskPattern::ALL>();
    Reg::RegTensor<uint16_t> sign,ones,zero;
    Reg::Duplicate(sign,uint16_t(0x8000),all); Reg::Duplicate(ones,uint16_t(0xffff),all);
    Reg::Duplicate(zero,uint16_t(0),all);
    for(uint16_t t=0;t<4;t++) {
        Reg::RegTensor<uint16_t> k,test,pos,neg,bits;
        Reg::LoadAlign(k,keys+t*128); Reg::And(test,k,sign,all);
        Reg::MaskReg positive;
        Reg::Compare<uint16_t,CMPMODE::EQ>(positive,test,sign,all);
        Reg::Xor(pos,k,sign,all); Reg::Xor(neg,k,ones,all);
        Reg::Select(bits,pos,neg,positive);
        Reg::RegTensor<int16_t> ar; Reg::Arange(ar,t*128);
        Reg::MaskReg valid;
        Reg::Compares<int16_t,CMPMODE::LT>(valid,ar,int16_t(count),all);
        Reg::Select(bits,bits,zero,valid);
        Reg::StoreAlign(dst+t*128,bits,all);
    }
}

