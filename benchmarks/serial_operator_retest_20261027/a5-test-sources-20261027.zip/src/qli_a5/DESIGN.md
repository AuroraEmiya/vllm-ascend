# 最终 C/V 设计

## 数学边界

C读取packed Q/K及E8M0 scale和PA页表，做native MXFP4 dot、FP32累加、BF16 RNE，输出完整signed raw QK，保留负数。
V对raw做ReLU，将权重转换BF16，并按head0..31执行BF16目的FMA，随后有效长度裁剪、sparse TopK与独立块级candidate TopK。
不能将逐head BF16 FMA替换成FP32一次reduce；candidate也不是token TopK除8去重。
精确BF16与合法TopK并列规则保持不变，未采用此前Compressor任务的宽松容差。

```mermaid
flowchart LR
 I["packed Q/K + scale + PA metadata"] --> C["C: MXFP4 dot / FP32累加 / BF16 RNE"]
 C --> R["GM raw BF16: Qcap × 32 × S_pad"]
 R --> V["V: ReLU / 加权头归约 / TopK"]
 W["w + 有效长度 + candidate配置"] --> V
 V --> O["sparse indices/values + candidate indices/length"]
```

## C调度

c_a_hybrid_alias4long_qgroup8是最终入口。短K大Q按共享plan选择c_a_qgroup8_pure，packed M256N128布局减少碎片搬运。
ND路径由c_a_alias4_long选择已有pair/quad。长域满足工作量条件才选择quad；设备端检查Sk及所辖PA页共享，不满足则回退。
不能把测试中的合成共享PA假定为实际生产输入总成立。短域保留pair，避免无条件quad回退退化。

## V四类shape分支

令Q为本chunk有效query，Nv为实际Vector核数，Sp为128对齐K容量。按以下优先级选择：

| family | 条件 | 实现 |
|---|---|---|
|4|512<Sp<=1024且Q>=2Nv|QGROUP8_N128；每核连续query-pair区间，双行计算与预取|
|3|Sp>16384|K分片局部TopK；SyncAll之后同kernel合并|
|2|其余Q>=2Nv|双query配对的ND路径|
|1|其余|单query的ND路径|

family是直调工程的tiling分支字段，并非标准注册形式TILING_KEY_IS。共4类，不按caseID或精确T特化。
family4连续pair分核是最后保留优化；打分/VF数学保持与父版本一致。奇数query与分核尾部有独立合法性门禁。
family3局部结果写workspace，经全核同步后合并；所有参与核必须遵循同步协议，不可增加随意early return。

## 生命周期与限制

Qcap1024复用raw与workspace，按chunk串行C→V；每chunk两个计算任务。plan同时约束qcap/Sp/Q/设备/布局。
raw为专用内部ABI，尽管张量外观是[Qcap,32,Sp]，packed路径物理排布不等于ND。
全12例固定输入PASS；补充动态shape/图重放、奇数尾部、共享页回退及RNE等门禁。详细历史见完整交接包。
瓶颈未完全解决：大T candidate off仍慢于B；完整raw落GM和串行边界可能有后续空间，未证明理论极限。
