# 接入说明

## 环境与构建

已验证环境：A5 Ascend950DT / DAV_3510，CANN9.3.0，Python3.11.10及原容器torch/torch_npu。
依赖CANN SDK、cmake、torch开发库。此前完整远端交接包附ENVIRONMENT_SNAPSHOT.txt；非跨版本通用二进制。
```bash
source /usr/local/Ascend/cann/set_env.sh
export PATH=/usr/local/python3.11.10/bin:$PATH
for op in c_a_qgroup8_pure c_a_alias_pair c_a_alias4 c_a_alias4_long v_a_pair512_contiguous; do
  bash generation/$op/build.sh || exit 1
done
```
C包装器是Python调度，不另编译；其余五目录分别生成SO。重编应在新解压目录完成，保留原测量库及hash。

## 外部输入输出

- q: uint8[T,32,64]，packed MXFP4；k: uint8[P,64,1,64]。
- q_descale: uint8[T,32,2,2]；k_descale: uint8[P,64,1,2,2]，E8M0字节载体；w: float32[T,32]。
- cu_seqlens_q / seqused_q / seqused_k / block_table 的dtype、合法范围按benchmark/definition.json及inputs.py构造，不能只凭shape猜测。
- sparse_indices int32[T,1,512]；sparse_values BF16[T,1,512]。
- candidate开启：indices int32[T,1,2048]、length int32[T,1]；关闭返回空int32张量。
- 当前功能域固定32 heads、D=128、TopK512；candidate=(-1,-1)或(2048,8)。不是任意参数通用实现。

## 单chunk调用示例

在包根目录运行；x为同设备、满足definition的输入字典。整个T按Qcap1024分chunk。
```python
import importlib.util
from pathlib import Path
import torch, torch_npu
root = Path.cwd()
def load_runner(name):
    spec = importlib.util.spec_from_file_location(name, root/'generation'/name/'runner.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
C = load_runner('c_a_hybrid_alias4long_qgroup8')
V = load_runner('v_a_pair512_contiguous')
C.load(); V.load()
start = 0
n = min(1024, x['q'].shape[0])
qcap = 1024
sp = ((x['block_table'].shape[1]*64+127)//128)*128
plan = C.make_plan(qcap, sp, n, device=x['q'].device)
raw = C.allocate_raw(plan, device=x['q'].device)
out = V.allocate_outputs(raw, n, x['candidate_topk_blocks'])
workspace = V.allocate_workspace(raw, qcap, x['candidate_topk_blocks'])
def run_chunk():
    C.run(x['q'][start:start+n], x['k'], x['q_descale'][start:start+n], x['k_descale'],
          x['cu_seqlens_q'], x['seqused_q'], x['seqused_k'], x['block_table'],
          start, n, qcap, plan=plan, out=raw)
    return V.run(raw, x['w'][start:start+n], x['cu_seqlens_q'], x['seqused_q'],
          x['seqused_k'], x['block_table'], start, n,
          x['candidate_topk_blocks'], x['candidate_block_size'],
          plan=plan, out=out, workspace=workspace)
result = run_chunk()
```
这是按现有runner ABI整理的示例，未另做运行测试；已验证完整集成入口在旧任务 generation/validation/cv_pipeline_alias4long_contiguous_cap1024.py。
全量接入应捕获每个chunk自己的start/n/plan，写入完整输出对应切片，不能只执行示例首chunk。
图捕获前完成库加载、plan创建及raw/out/workspace分配。C和V必须使用同一stream和同一plan；不在图内重新分配。
raw逻辑shape相同但物理布局可能QGROUP8_N128，禁止直接按普通ND解释、clone后丢失plan或单边替换C/V。
多stream并发调用需要独立raw/workspace/out；不要并发复用同一缓冲区。
本包没有新增vLLM注册/部署步骤，业务侧需用自己的张量和请求metadata接入。

## 验证与复现

输入用benchmark/inputs.py重建并核对evidence中的输入hash；不要修改已冻结输入使其迁就kernel。
完整正确性、A/B驱动及msprof采集使用既有完整交接包，入口 handoff/HANDOFF.md。
部署后先跑单例和边界，再全12例；重编产物需建立新hash，历史PASS不自动覆盖新环境。
