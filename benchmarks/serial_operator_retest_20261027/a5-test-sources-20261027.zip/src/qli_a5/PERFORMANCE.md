# QLI A5 performance evidence

Speedup is baseline device time divided by our C+V device time; values above 1 mean our implementation is faster. Measurement used A5 (Ascend 950DT / DAV_3510), graph mode, W5/R20, and msprof device-task duration, excluding host dispatch. The 12 original cases receive equal weight in the geometric mean. All chunks are included. A retains its frozen measurement; B was remeasured with the same inputs and candidate setting.

| Comparison | Cases | Geometric mean | Reading |
|---|---:|---:|---|
| Our C+V vs A, candidate off | 6 | 2.098778× | Target 1.2× met; A has no candidate output, so only off cases are comparable |
| Our C+V vs B, candidate off | 6 | 1.154636× | Candidate-off subset |
| Our C+V vs B, candidate on | 6 | 1.479852× | Candidate-on subset |
| Our C+V vs B, all cases | 12 | 1.307169× | Overall 1.4× target not met |

| Case | T | Sₖ | Candidate | C (µs) | V (µs) | C+V (µs) | B (µs) | Speedup vs B |
|---:|---:|---:|:---:|---:|---:|---:|---:|---:|
| 0 | 16 | 1021 | off | 3.421 | 3.604 | 7.025 | 8.205 | 1.1680× |
| 1 | 16 | 1021 | on | 3.387 | 4.808 | 8.195 | 9.705 | 1.1843× |
| 2 | 16 | 32773 | off | 14.278 | 13.905 | 28.184 | 99.414 | 3.5274× |
| 3 | 16 | 32773 | on | 14.118 | 17.627 | 31.745 | 103.019 | 3.2452× |
| 4 | 64 | 1021 | off | 5.182 | 5.462 | 10.643 | 14.645 | 1.3760× |
| 5 | 64 | 1021 | on | 5.204 | 6.504 | 11.708 | 18.219 | 1.5561× |
| 6 | 131072 | 1021 | off | 2386.857 | 2619.066 | 5005.923 | 3798.170 | 0.7587× |
| 7 | 131072 | 1021 | on | 2431.042 | 3158.204 | 5589.247 | 6839.232 | 1.2236× |
| 8 | 524288 | 1021 | off | 9669.144 | 10577.182 | 20246.325 | 15139.445 | 0.7478× |
| 9 | 524288 | 1021 | on | 9866.754 | 12744.577 | 22611.331 | 27300.385 | 1.2074× |
| 10 | 2097152 | 1021 | off | 39405.577 | 42730.105 | 82135.682 | 60513.176 | 0.7367× |
| 11 | 2097152 | 1021 | on | 40650.561 | 51048.642 | 91699.203 | 109006.749 | 1.1887× |

Per-case source measurements and comparison identity are preserved in [`evidence/FINAL_RESULTS.json`](evidence/FINAL_RESULTS.json), [`evidence/profile_b_final_full_r57.json`](evidence/profile_b_final_full_r57.json), and [`evidence/COMPARISON_CORRECTED.json`](evidence/COMPARISON_CORRECTED.json). `SOURCE_MANIFEST.json` records the source package manifest.

## Workload and limits

Correctness validation on the historical final C/V kernel package passed all 12 cases across 5,505,216 query rows. The 12 cases cover T = 16, 64, 131072, 524288, and 2097152, with candidate off/on and a long-key subset. The measured C and V are serial stages; this is not a fused kernel result.

The shape anchors came from A5 simulation CSVs. Sequence metadata, batch segmentation, and shared physical pages were legal synthetic assumptions, not direct production invocations. Results are not weighted by production request frequency. Large-T candidate-off cases remain slower than B, so the overall mean masks that regression.

The current unified Python package adds a new public entry point and graph preparation wrapper. It was not rebuilt or run on NPU in this local packaging pass; the measurements above identify the final C/V kernels and do not establish end-to-end timing or correctness for that adapter. No NPU validation was performed while creating this deliverable.
